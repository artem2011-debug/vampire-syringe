# Как собрать мод через GitHub (без установки Java и Gradle)

GitHub сам соберёт jar на своих серверах бесплатно. Нужен только аккаунт на github.com.

## 1. Создай репозиторий
1. Зайди на github.com и войди в аккаунт (или зарегистрируйся).
2. Нажми **+** (справа вверху) -> **New repository**.
3. Название — любое, например `demon-syringe`. Видимость — Private или Public, без разницы.
4. Галочки **Add a README / .gitignore / license НЕ ставь** (репозиторий должен быть пустым).
5. Нажми **Create repository**.

## 2. Загрузи файлы проекта
Важно: в корне репозитория должны лежать `build.gradle`, `gradle.properties`, `settings.gradle`, папка `src` и скрытая папка `.github`. Не должно быть лишней папки `vampire-syringe/` сверху.

1. Распакуй архив `vampire-syringe-stage7.zip` на компьютере и зайди ВНУТРЬ папки `vampire-syringe`.
2. В пустом репозитории нажми ссылку **uploading an existing file**.
3. Выдели всё содержимое папки (`src`, `build.gradle`, `README.md` и т.д.) и перетащи в окно браузера. Папки грузятся вместе с вложенными файлами.
4. Внизу нажми **Commit changes**.

### Если папка `.github` не загрузилась
Скрытые папки (с точкой) браузер иногда пропускает. Проверь: в репозитории должен быть файл `.github/workflows/build.yml`. Если его нет:
1. **Add file -> Create new file**.
2. В поле имени набери `.github/workflows/build.yml` (слэши сами создадут папки).
3. Вставь туда содержимое файла `build.yml` из архива.
4. **Commit changes**.

### Вариант через git (если установлен)
```
cd vampire-syringe
git init
git add .
git commit -m "Demon Syringe 1.7.2"
git branch -M main
git remote add origin https://github.com/ТВОЙ_НИК/demon-syringe.git
git push -u origin main
```

## 3. Дождись сборки
1. Открой вкладку **Actions** в репозитории.
2. Там появится запуск **build** (жёлтый кружок = идёт, обычно 3–6 минут; первая сборка дольше, она скачивает Minecraft).
3. Если Actions выключены, нажми зелёную кнопку **I understand my workflows, go ahead and enable them**.
4. Запустить сборку вручную можно так: Actions -> **build** -> **Run workflow**.

## 4. Скачай мод
1. Нажми на завершённый запуск (зелёная галочка).
2. Внизу страницы, в блоке **Artifacts**, нажми **vampire-syringe**. Скачается zip.
3. Распакуй его. Внутри лежит `vampire-syringe-1.7.2.jar` — это и есть мод.

## 5. Установка в игру
- Нужны: Minecraft **1.21.1**, **Fabric Loader 0.16.x** и **Fabric API 0.115.0+1.21.1** (Fabric API кладётся в `mods` отдельным файлом, скачать на modrinth.com).
- Положи `vampire-syringe-1.7.2.jar` и Fabric API в папку `.minecraft/mods`.
- Для сервера то же самое: jar мода и Fabric API в папку `mods` сервера. Мод нужен и на сервере, и у игроков.

## 6. Если сборка упала (красный крестик)
1. Actions -> нажми на упавший запуск -> шаг **Build** -> раскрой лог.
2. Скопируй последние 40–60 строк (с ошибкой `error:` или `What went wrong`) и пришли мне, исправлю.

## Выпуск версии (по желанию)
Чтобы получить красивую страницу со скачиванием jar без захода в Actions:
1. В репозитории: **Releases -> Create a new release**.
2. В поле Tag введи `v1.7.2`, нажми **Create new tag**, затем **Publish release**.
3. Через несколько минут сборка прикрепит jar к релизу сама.

## Как обновлять мод
Заменяй изменённые файлы в репозитории (**Add file -> Upload files**, файлы с тем же именем перезапишутся) и делай Commit. Каждый коммит запускает новую сборку. Версию мода меняй в `gradle.properties` (`mod_version`).
