# Demon Syringe (бывш. Vampire Syringe) 1.7.2 (Fabric 1.21.1, Mojang mappings)

Сборка: `gradle build` (Java 21) -> `build/libs/vampire-syringe-1.7.2.jar`.
Либо залей проект в GitHub — workflow `.github/workflows/build.yml` соберёт jar сам (Actions -> artifact). Подробная пошаговая инструкция — в `BUILD_GITHUB.md`.

## Правки после этапа 7 (1.7.2)
- **Затемнение рисуется миксином ПОД HUD** — `mixin/client/GuiMixin.java` (НОВЫЙ, подключён в `vampire.client.mixins.json`): вставка в начало `Gui.render(GuiGraphics, DeltaTracker)`. К этому моменту мир уже нарисован, а сердца, капли крови, хотбар, чат и подписи — ещё нет, поэтому HUD остаётся ярким и читаемым. `VampireClient.renderScreenTint` теперь `public`, а `HudRenderCallback` рисует только подпись фракции и шкалу истребителя. Красная вспышка при поедании тоже идёт под HUD. По F1 затемнение скрывается вместе с HUD
- **Мир всегда виден**: темнота нужна, чтобы игрок понял «мне плохо, надо поесть», а не чтобы ослепить его. Раньше на нуле было почти чёрное покрытие (0,97). Теперь это лёгкая равномерная дымка (`Cfg.VITALITY_DARKEN_MAX_ALPHA` = 0,40) плюс виньетка по краям (`VITALITY_VIGNETTE_MAX_ALPHA` = 0,60, `VITALITY_VIGNETTE_DEPTH` = 0,35, `VITALITY_VIGNETTE_LAYERS` = 14) — центр экрана светлый. `Vitality.darkness()` теперь возвращает силу 0..1, а реальную прозрачность считает клиент по этим числам. Хочешь темнее/светлее — меняй только эти два значения
- **Серый экран убран полностью**: удалены `GrayPayload.java`, `Cfg.GRAY_HP`, серая заливка на клиенте и вся отправка этого пакета в `VampireLogic`/`VampireMod`. Ограничение «при смерти» (на последнем сердце нельзя ломать блоки и использовать предметы) осталось — клиент теперь считает его сам: вампир со здоровьем ≤ `Cfg.LAST_STAND_HP`
- **GitHub**: `.github/workflows/build.yml` переписан (запуск по push / вручную / по тегу `v*`, в артефакте один jar, при теге — GitHub Release), `build.gradle` — убран `-sources.jar`, версия 1.7.2. Инструкция — `BUILD_GITHUB.md`
- Таблица затемнения без игры: `java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -d out src/main/java/com/vampiresyringe/Cfg.java src/main/java/com/vampiresyringe/Faction.java src/main/java/com/vampiresyringe/Vitality.java && java -Dstdout.encoding=UTF-8 -cp out com.vampiresyringe.Vitality`
- Не проверено сборкой (Minecraft и Gradle в среде правки недоступны). Миксин `GuiMixin` целится в `Gui.render(GuiGraphics, DeltaTracker)` — сигнатура 1.21.1. Если игра упадёт при запуске с ошибкой про `GuiMixin`, пришли лог

## Правки после этапа 6: поедание, клавиша регенерации, самочувствие
Все числа ниже — в `Cfg.java` (блоки «БЫСТРАЯ РЕГЕНЕРАЦИЯ», «ПОЕДАНИЕ», «САМОЧУВСТВИЕ»).

- **Поедание: Shift + ПКМ по существу** (`VampireLogic.java`: `onUseEntity`, `tickDevours`, `devourBite`). Раньше кровь пилась ударом голой руки — теперь удар кулаком обычный, а демон (и вампир без фракции; истребитель — нет) начинает «трапезу», нажав Shift и ПКМ по живому существу с кровью **с пустой основной рукой**. Он пожирает жертву заживо, пока держит Shift: 4 укуса по 0,5 с (всего 2 с), кровь жертвы делится между укусами (прогресс ранга и лечение — за каждый укус), жертва не может убежать и стоит на месте, последний укус её добивает (убийство засчитывается демону — награда за моба «без ранга» работает как раньше, кровь второй раз не начисляется). Отпустил Shift, убрал руку, отошёл дальше `DEVOUR_RANGE` (3,5 блока) — трапеза прервана, жертва остаётся раненой. Без Shift ПКМ работает как в ваниле (торговля с жителем и т.д.); с предметом в руке — тоже. Шкала крови полна — «Ты не голоден», трапеза не начинается; наполнилась по ходу — жертва всё равно съедается, лишняя кровь пропадает. Мобы без крови (`NO_BLOOD`) и игроки, как и раньше, не кусаются
- **Быстрая регенерация — отдельная клавиша, по умолчанию «B»** (`client/VampireClient.java`, `RegenKeyPayload.java` — НОВЫЙ, `VampireMod.java`, `VampireLogic.java` `fastTick`). Лечение, которое раньше шло от зажатого приседа, теперь идёт, пока зажата эта клавиша (через `Cfg.REGEN_HOLD_TICKS` = 10 тиков). Клавиша появилась в «Настройки -> Управление», категория «Demon Syringe», пункт «Быстрая регенерация (демон)» — переназначается как любая другая. Клиент шлёт серверу только смену «зажата/отпущена». Скорость и цена лечения прежние (`REGEN_FULL_SECONDS`, `REGEN_BLOOD_FRACTION`, множитель по рангу), блокируется горением на солнце, как раньше. `Cfg.SNEAK_HOLD_TICKS` переименован в `REGEN_HOLD_TICKS`
- **Самочувствие: затемнение экрана и замедление** (`Vitality.java` — НОВЫЙ, без зависимостей от Minecraft; `client/VampireClient.java`, `VampireLogic.java` `slowTick`). Самочувствие = **меньшая из двух долей: здоровье и кровь** (здоровье считается от «пола» — у демона от 1 HP, у вампира без фракции от последнего сердца). Обе шкалы полные — экран чистый; обе наполовину — затемнён (~44%); любая шкала пуста — почти чёрный (`VITALITY_DARKEN_MAX_ALPHA` = 0,97), причём неважно, полна ли вторая. То же самое для замедления: самочувствие ниже 0,30 / 0,20 / 0,10 / 0,04 даёт «Замедление» I / II / III / V (на нуле — -75% скорости), а скоростные баффы по рангу при этом отключаются. Затемнение плавное (около секунды на переход), работает только там, где вместо еды капли крови, и не действует в творческом режиме и наблюдателе. (Серого экрана при ≤2 сердцах больше нет — убран в 1.7.2.) Таблица без запуска игры: `java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -d out src/main/java/com/vampiresyringe/{Cfg,Faction,Vitality}.java && java -Dstdout.encoding=UTF-8 -cp out com.vampiresyringe.Vitality`
- **Красноватая вспышка при поедании** (`DevourFlashPayload.java` — НОВЫЙ, `VampireClient.java`). На старте трапезы сервер шлёт клиенту сигнал, экран на 2 секунды (`DEVOUR_FLASH_TICKS` = 40) плавно краснеет (до `DEVOUR_FLASH_MAX_ALPHA` = 0,38) и так же плавно возвращается к обычному цвету
- Тексты: `lang/*` (+`key.vampire.regen`, `key.categories.vampire`), сообщение при первом уколе в `SyringeItem.java` объясняет новое управление и показывает **текущую** клавишу регенерации (подставляется из настроек игрока)
- **Важно:** новый демон стартует с половиной шкалы крови (`VampireData`: `MAX_BLOOD / 2`), поэтому сразу после укола экран уже затемнён примерно на 44% — пока не поешь. Хочется иначе — поменяй стартовую кровь в `VampireData` или `VITALITY_DARKEN_COMFORT` в `Cfg`
- ~~Ограничение: затемнение поверх HUD~~ — снято в 1.7.2, теперь миксин `GuiMixin` рисует его под HUD
- Проверка в игре: `/demon setfaction demon`, `/summon minecraft:villager ~ ~ ~` -> Shift + ПКМ по жителю (красная вспышка, 4 укуса, кровь растёт, житель погибает); зажать B при неполном здоровье — лечение; `/damage @s 18 minecraft:generic` -> остаётся 1 HP: экран чёрный, игрок еле ползёт; поесть до полной крови и не бить — экран светлеет
- Не проверено сборкой: Minecraft и Gradle в среде, где правилось, недоступны, поэтому `gradle build` не запускался. Класс `Vitality` скомпилирован и запущен отдельно, остальной код проверен на синтаксис и сверен вручную с API Fabric 0.115 / Mojang mappings 1.21.1. Если сборка на GitHub Actions упадёт — пришли лог ошибки

## Правки после этапа 5
- **Демоны-мобы горят на солнце по канону** — `DemonMob.java`, `SunBurn.java`, `SunLight.java` (НОВЫЙ), `Cfg.java`: вместо ванильного поджога (1 HP/с, который высокоранговый моб почти не замечал) на прямом солнце моб получает урон `vampire:sun` (мимо брони и сопротивления), `Cfg.DEMON_MOB_SUN_DAMAGE_PER_SEC_MIN/MAX` = 5..8 HP/с (смерть за ~4 с у Низшего 6 и ~9 с у Высшего 1), после ухода в тень догорает по рангу; вода и дождь тушат; шлем не спасает; с горящего сыплется пепел, умерший от солнца рассыпается пеплом. Подкрепления из обычных зомби демон-моб не зовёт. Игроков-демонов это не касается — у них прежние 4..6 HP/с. Таблица: `SunBurn.main`
- **«Вампир» -> «демон» в названиях**: `lang/*` (шприц — «Шприц демона», эффект — «Демонизм»), сообщения в игре, название мода в `fabric.mod.json`, команда `/demon` (старая `/vampire` работает так же). Внутренние id (`vampire:`, тег `vampire`, пакет `com.vampiresyringe`, имя jar) НЕ менялись, чтобы не сломать миры, команды и датапаки
- **Ранг демону — не сразу**: у нового демона ранг 0 «Без ранга» (`Faction.java`: `isUnranked`, `tableRank`; `Cfg.DEMON_FIRST_RANK_PROGRESS` = 60, `DEMON_UNRANKED_MOB_KILL_PROGRESS` = 8). Прогресс даёт поглощённая кровь (3 за очко) и убитые мобы (8 за моба; разбойник — своя награда); набрав 60, демон получает ранг 1 (Низший 6), излишек переносится. Пока ранга нет, характеристики как у ранга 1. `RankProgress.java`, `SyringeItem.java`, `RankStats`/`BloodScale`/`SunBurn`/`ProgressRewards` (индексы таблиц через `tableRank`), HUD «До ранга: x / 60». `/demon setrank 0` возвращает демона «без ранга»
- **Истребитель — шкала концентрации**: `client/VampireClient.java` (`renderSlayerHud`) рисует над самым верхним рядом сердец/брони шкалу на ширину хотбара (пока декоративная, `Cfg.SLAYER_CONCENTRATION_DECOR_FILL`), выше — название ранга, если истребитель чего-то добился (ранг выше Мизуноки или есть прогресс; `Cfg.SLAYER_RANK_HUD_ALWAYS = true` — показывать всегда). У истребителя вместо капель крови обычные окорочка (`showsBloodBar()` + `GuiGraphicsMixin`); шприц истребитель принять не может
- Проверка: `/demon setfaction demon` -> «Без ранга», кусай мобов/жителей — прогресс на HUD, на 60 придёт «тебе присвоен ранг»; `/demon setfaction slayer` -> шкала над HP/едой; `/summon vampire:demon_mob ~ ~ ~` днём под открытым небом -> горит и рассыпается пеплом
- Проверка баланса без игры: `java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -d out src/main/java/com/vampiresyringe/{Cfg,Faction,BloodScale,RankStats,SunBurn,ProgressRewards}.java && java -Dstdout.encoding=UTF-8 -cp out com.vampiresyringe.SunBurn`

## Этап 4: зачарование «Испепеление солнца»
- `data/vampire/enchantment/sun_incineration.json` — НОВЫЙ: уровни I-III, только мечи (`#minecraft:enchantable/sword`), слот mainhand
- `data/minecraft/tags/enchantment/{tradeable,on_random_loot,double_trade_price}.json` — НОВЫЕ: книга в сундуках и у библиотекарей (двойная цена)
- `data/vampire/damage_type/sun_pierce.json` + теги `bypasses_*` и `no_knockback` — НОВЫЙ доп. урон «пробивает кожу» (мимо брони, зачарований, эффектов, кадров неуязвимости)
- `SunWoundEffect.java` — НОВЫЙ: метка «Солнечная рана», режет пассивную регенерацию демона
- `SunIncineration.java` — НОВЫЙ: удар по демону -> доп. урон и метка в конце тика
- `Cfg.java` — блок «ЗАЧАРОВАНИЕ (ЭТАП 4)»: урон, длительность и срез регенерации по уровням
- `VampireMod.java` — `SUN_PIERCE`, `SUN_WOUND`, регистрация эффекта и `SunIncineration.register()`
- `VampireLogic.java` — `allowDamage` зовёт `SunIncineration.onDemonHit`, `canKillDemon` пропускает `sun_pierce`, `passiveRegen` учитывает метку
- Проверка: `/give @s enchanted_book[stored_enchantments={"vampire:sun_incineration":3}]`, `/give @s diamond_sword[enchantments={"vampire:sun_incineration":3}]`

## Этап 3: смерть от солнца
- `data/vampire/damage_type/sun.json` — НОВЫЙ DamageType `vampire:sun` (сообщения `death.attack.vampire_sun*` в `lang/*`)
- `data/minecraft/tags/damage_type/bypasses_{armor,cooldown,effects,enchantments,resistance}.json` — НОВЫЕ: солнце не режется бронёй, зельями, зачарованиями и не глотается «кадром неуязвимости»
- `SunBurn.java` — НОВЫЙ: урон (4..6 HP/с по рангу) и время догорания по рангу, `main` печатает таблицу баланса
- `Cfg.java` — блок «СОЛНЦЕ (ЭТАП 3)»: `DEMON_DEATH_FLOOR_HP`, `DEMON_SUN_DAMAGE_PER_SEC_*`, `DEMON_SUN_BURN_TICKS`, id зачарования
- `VampireMod.java` — ключи `SUN_DAMAGE` и `SUN_SLAYING_ENCHANTMENT` (`vampire:sun_incineration`, само зачарование — Этап 4)
- `VampireLogic.java` — `allowDamage`/`allowDeath`: демон не умирает от обычного урона (остаётся 1.0F), солнце и оружие с «Испепелением солнца» убивают; `sunBurnStep()` в `slowTick`; горящий демон не лечится; сброс горения при респавне
- Проверка баланса: `java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -d out src/main/java/com/vampiresyringe/{Cfg,Faction,BloodScale,RankStats,SunBurn}.java && java -Dstdout.encoding=UTF-8 -cp out com.vampiresyringe.SunBurn`
- Проверка в игре: `/damage @s 100 vampire:sun` убивает демона, `/damage @s 100 minecraft:generic` — оставляет 1.0F

## Этап 2: характеристики по рангам
- `RankStats.java` — НОВЫЙ: бонусы по фракции и рангу (читает таблицы из `Cfg`), `main` печатает таблицу баланса
- `Cfg.java` — таблицы `DEMON_*` (1..12) и `SLAYER_*` (1..6); `DEMON_UPPER_BLOOD_MULT_STEP` 0.20 -> 0.35
- `VampireLogic.java` — `refreshStats()` (модификаторы атрибутов с фиксированными id, идемпотентно), пассивная регенерация за кровь, ночное зрение по рангу, лечение приседом зависит от ранга
- `SyringeItem.java` — после смены фракции/ранга атрибуты обновляются сразу
- Проверка баланса: `java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -d out src/main/java/com/vampiresyringe/{Cfg,Faction,BloodScale,RankStats}.java && java -Dstdout.encoding=UTF-8 -cp out com.vampiresyringe.RankStats`

## Этап 1: фракции, ранги, шкала крови под ранг
- `Faction.java` — НОВЫЙ: NONE / DEMON / SLAYER, диапазоны рангов, пороги прогресса
- `BloodScale.java` — НОВЫЙ: максимум крови по фракции и рангу (общий для сервера и клиента)
- `VampireData.java` — поля `faction`, `rank`, `rankProgress`, `sunBurnTicks` (NBT: `faction`, `rank`, `rank_progress`, `sun_burn_ticks`)
- `VampireStatePayload.java` — в пакет добавлены фракция, ранг, прогресс, таймер горения
- `Cfg.java` — шаг шкалы, множители рангов, потолок, пороги рангов, настройки проверки укола
- `VampireLogic.java` — максимум крови из `VampireData.maxBlood()`, рассылка состояния при любом изменении
- `client/VampireClient.java`, `mixin/client/GuiGraphicsMixin.java` — шкала крови рисуется под текущий максимум (до 4 рядов по 10 капель)
- `SyringeItem.java` — первый укол делает демоном ранга 1; `Cfg.DEBUG_SYRINGE_RANK_UP` для проверки рангов
- `lang/*` — названия фракций и рангов

## Что изменилось в 1.7.1 (относительно 1.7.0)
Капли крови теперь видит ТОЛЬКО вампир. У людей — обычная полоска голода с окорочками.
- Текстуры капель перенесены из `assets/minecraft/.../hud/food_*.png` (глобальная подмена для всех)
  в `assets/vampire/textures/gui/sprites/hud/blood_*.png` — ванильные спрайты больше не перекрываются
- `mixin/client/GuiGraphicsMixin.java` — НОВЫЙ: у вампира спрайты `food_*` подменяются на `blood_*`
- `vampire.client.mixins.json`, `fabric.mod.json` — подключение миксина (Mixin встроен в Fabric Loader, новых библиотек нет)
- `VampireStatePayload.java` — НОВЫЙ пакет сервер -> клиент «ты вампир / не вампир» (тег `vampire` живёт только на сервере)
- `VampireMod.java` — регистрация пакета; `VampireLogic.java` — рассылка состояния при входе, респавне и смене тега
  (`/tag <игрок> add|remove vampire` меняет вид полоски сразу); `client/VampireClient.java` — приём пакета

## Что изменилось в 1.7.0 (относительно 1.6.0)
- `VampireLogic.java` — бессмертие на последнем сердце, состояние «при смерти», единый эффект, кровь вместо голода
- `VampirismEffect.java` — НОВЫЙ, эффект «Вампиризм»
- `VampireMod.java` — регистрация эффекта
- `client/VampireClient.java` — клиентская отмена действий «при смерти»
- `Cfg.java` — описание LAST_STAND_HP
- `assets/vampire/lang/*`, `assets/vampire/textures/mob_effect/vampirism.png` — название и иконка эффекта
- `assets/minecraft/textures/gui/sprites/hud/food_*.png` — капли вместо drumsticks
- `SyringeItem`, `GrayPayload`, `VampireData` — по смыслу без изменений
