package com.vampiresyringe;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Этап 4: боевая часть зачарования «Испепеление солнца» (vampire:sun_incineration, уровни I-III, меч).
 * Удар таким оружием по ДЕМОНУ:
 *  1) наносит небольшой доп. урон vampire:sun_pierce, игнорирующий броню/зачарования/эффекты («пробивает кожу»);
 *  2) вешает метку «Солнечная рана» (vampire:sun_wound), режущую пассивную регенерацию;
 *  3) снимает бессмертие — это делает VampireLogic.canKillDemon (смертельный удар таким оружием убивает).
 *
 * Доп. урон и метка применяются в конце тика, а не внутри allowDamage: вложенный hurt() внутри удара
 * съел бы часть основного урона из-за кадров неуязвимости.
 */
public final class SunIncineration {
    private SunIncineration() {}

    private record Pending(UUID victim, UUID attacker, int level, float amount) {}

    private static final List<Pending> pending = new ArrayList<>();

    public static void register() {
        ServerLifecycleEvents.SERVER_STARTING.register(server -> pending.clear());
        ServerTickEvents.END_SERVER_TICK.register(SunIncineration::flush);
    }

    /** Уровень «Испепеления солнца» на оружии, которым нанесён урон (0 — нет оружия или зачарования). */
    public static int enchantLevel(Level level, DamageSource source) {
        ItemStack weapon = source.getWeaponItem();
        if (weapon == null || weapon.isEmpty()) return 0;
        Optional<Holder.Reference<Enchantment>> ench = level.registryAccess()
                .registryOrThrow(Registries.ENCHANTMENT).getHolder(VampireMod.SUN_SLAYING_ENCHANTMENT);
        return ench.map(h -> EnchantmentHelper.getItemEnchantmentLevel(h, weapon)).orElse(0);
    }

    /** Индекс в таблицах Cfg по уровню зачарования (уровни выше III, выданные командой, считаются как III). */
    private static int idx(int level) {
        return Math.max(0, Math.min(level, Cfg.SUN_INCINERATION_MAX_LEVEL) - 1);
    }

    /**
     * Зовётся из VampireLogic.allowDamage ДО применения урона, только для демона. Ставит доп. урон и метку в очередь.
     * Не срабатывает на собственный урон мода (солнце, пронзание), в кадрах неуязвимости жертвы и при нулевом уроне.
     */
    public static void onDemonHit(ServerPlayer victim, DamageSource source, float amount) {
        if (source.is(VampireMod.SUN_DAMAGE) || source.is(VampireMod.SUN_PIERCE)) return;
        if (amount <= 0f || victim.invulnerableTime > 10) return; // удар всё равно будет отброшен кадром неуязвимости
        Entity attacker = source.getEntity();
        if (attacker == null) return;
        int lvl = enchantLevel(victim.level(), source);
        if (lvl <= 0) return;

        float extra = Math.min(Cfg.SUN_PIERCE_DAMAGE[idx(lvl)], amount); // доп. урон не больше самого удара
        pending.add(new Pending(victim.getUUID(), attacker.getUUID(), lvl, extra));
    }

    private static void flush(MinecraftServer server) {
        if (pending.isEmpty()) return;
        List<Pending> batch = new ArrayList<>(pending);
        pending.clear();
        for (Pending p : batch) {
            ServerPlayer victim = server.getPlayerList().getPlayer(p.victim());
            if (victim == null || !victim.isAlive()) continue; // умер от самого удара — метка не нужна
            ServerLevel level = (ServerLevel) victim.level();
            Entity attacker = level.getEntity(p.attacker());

            // источник без прямой сущности: нет повторного срабатывания (getWeaponItem == null), нет случайного
            // отбрасывания (тег no_knockback), а убийце всё равно засчитывается (getEntity)
            DamageSource src = new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                    .getHolderOrThrow(VampireMod.SUN_PIERCE), null, attacker);
            if (!victim.hurt(src, p.amount())) continue; // удар не прошёл (креатив, PvP выключен…) — метки нет
            if (!victim.isAlive()) continue;

            victim.addEffect(new MobEffectInstance(VampireMod.SUN_WOUND, Cfg.SUN_WOUND_TICKS[idx(p.level())],
                    idx(p.level()), false, true, true), attacker);
        }
    }

    /** Множитель пассивной регенерации: 1.0 без метки, меньше — пока висит «Солнечная рана». */
    public static double regenFactor(LivingEntity e) {
        MobEffectInstance wound = e.getEffect(VampireMod.SUN_WOUND);
        if (wound == null) return 1.0;
        double cut = Cfg.SUN_WOUND_REGEN_CUT[idx(wound.getAmplifier() + 1)];
        return Math.max(0.0, 1.0 - cut);
    }
}
