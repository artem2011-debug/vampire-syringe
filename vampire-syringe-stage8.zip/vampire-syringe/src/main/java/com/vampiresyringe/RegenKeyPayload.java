package com.vampiresyringe;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Клиент -> сервер: зажата ли клавиша быстрой регенерации (по умолчанию «B»). Шлётся только при смене состояния.
 * Саму клавишу игрок переназначает в Настройки -> Управление; серверу всё равно, какая именно кнопка.
 */
public record RegenKeyPayload(boolean held) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<RegenKeyPayload> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(VampireMod.MOD_ID, "regen_key"));
    public static final StreamCodec<ByteBuf, RegenKeyPayload> CODEC =
            ByteBufCodecs.BOOL.map(RegenKeyPayload::new, RegenKeyPayload::held);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
