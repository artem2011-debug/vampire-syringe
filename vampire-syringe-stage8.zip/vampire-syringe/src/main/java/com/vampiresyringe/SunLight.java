package com.vampiresyringe;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;

/**
 * Единое для игроков-демонов и демонов-мобов правило «стоит ли существо под прямым солнцем».
 * День — только в Верхнем мире (в Незере и Энде солнца нет); ночь — с 12400 по 23500 тик суток.
 */
public final class SunLight {
    private SunLight() {}

    /** Светит ли солнце в этом мире сейчас (Верхний мир, не ночь). */
    public static boolean isDaytime(Level level) {
        if (level.dimension() != Level.OVERWORLD) return false;
        long t = level.getDayTime() % 24000L;
        return !(t >= 12400 && t <= 23500);
    }

    /** Прямое солнце: день, существо не в воде и над головой нет блоков. Дождь и «Превращение» проверяет вызывающий. */
    public static boolean exposed(Entity e) {
        Level level = e.level();
        if (!isDaytime(level) || e.isInWater()) return false;
        return level.canSeeSky(BlockPos.containing(e.getX(), e.getEyeY(), e.getZ()));
    }
}
