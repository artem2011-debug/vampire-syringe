package com.vampiresyringe;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;

/**
 * Этап 5: начисление прогресса ранга и повышение ранга. Всё идёт через {@link #add}: прогресс копится в
 * VampireData.rankProgress, при достижении порога ранг растёт (излишек переносится на следующий), после чего
 * пересчитываются характеристики (VampireLogic.refreshStats) и шкала крови (максимум зависит от ранга; доля заполнения сохраняется).
 *
 * Новообращённый демон идёт «без ранга» (ранг 0): пока он не наберёт Cfg.DEMON_FIRST_RANK_PROGRESS, ранга у него нет;
 * набрав, он получает ранг 1 (Низший 6) — отдельным сообщением «ранг присвоен».
 *
 * Источники:
 *  - демон: поглощённая кровь (onBlood), победа над разбойником и — пока ранга нет — любой убитый моб (onKill);
 *  - истребитель: убийство демона — демона-моба или игрока-демона (onKill), награда зависит от ранга демона.
 * Размеры наград — ProgressRewards / Cfg.
 */
public final class RankProgress {
    private RankProgress() {}

    /** Откуда пришёл прогресс (ключ — для текста сообщения «vampire.message.progress.<key>»). */
    public enum Source {
        BLOOD("blood"), BANDIT("bandit"), DEMON("demon"), MOB("mob");
        final String key;
        Source(String key) { this.key = key; }
    }

    // ================= ИСТОЧНИКИ =================
    /** Демон поглотил кровь: gained — сколько очков реально добавилось в шкалу. */
    public static void onBlood(ServerPlayer p, VampireData d, double gained) {
        if (d.faction != Faction.DEMON) return;
        add(p, d, ProgressRewards.demonBlood(gained), Source.BLOOD);
    }

    /**
     * Игрок killer убил dead. hasVampireTag — есть ли у убийцы тег вампира (демон без тега ведёт себя как человек,
     * прогресса не получает; истребителю тег не нужен).
     */
    public static void onKill(ServerPlayer killer, LivingEntity dead, boolean hasVampireTag) {
        VampireData kd = killer.getAttached(VampireMod.DATA);
        if (kd == null || killer == dead) return;

        if (kd.faction == Faction.SLAYER) {
            int demonRank = demonRankOf(dead);
            if (demonRank > 0) add(killer, kd, ProgressRewards.slayerKill(demonRank, kd.rank), Source.DEMON);
        } else if (kd.faction == Faction.DEMON && hasVampireTag) {
            if (dead instanceof BanditMob bandit) {
                add(killer, kd, ProgressRewards.banditKill(bandit.getPower(), kd.rank), Source.BANDIT);
            } else if (Faction.DEMON.isUnranked(kd.rank) && dead instanceof Mob) {
                // «без ранга»: сожранный моб тоже приближает к первому рангу (игроки и стойки сюда не попадают)
                add(killer, kd, Cfg.DEMON_UNRANKED_MOB_KILL_PROGRESS, Source.MOB);
            }
        }
    }

    /** Ранг убитого демона (моб или игрок-демон), 0 — это не демон. */
    private static int demonRankOf(LivingEntity dead) {
        if (dead instanceof DemonMob mob) return mob.getDemonRank();
        if (Cfg.SLAYER_PROGRESS_FROM_DEMON_PLAYERS && dead instanceof ServerPlayer victim) {
            VampireData vd = victim.getAttached(VampireMod.DATA);
            if (vd != null && vd.faction == Faction.DEMON) return vd.rank;
        }
        return 0;
    }

    // ================= НАЧИСЛЕНИЕ И ПОВЫШЕНИЕ =================
    /** Начисляет прогресс; при достижении порога (порогов) повышает ранг. На максимальном ранге ничего не делает. */
    public static void add(ServerPlayer p, VampireData d, int amount, Source source) {
        Faction f = d.faction;
        if (amount <= 0 || f.rankUpProgress(d.rank) == 0) return; // нет фракции или ранг уже максимальный

        int oldRank = d.rank;
        boolean wasUnranked = f.isUnranked(oldRank);
        double frac = bloodFraction(d);

        d.rankProgress += amount;
        int need;
        while ((need = f.rankUpProgress(d.rank)) > 0 && d.rankProgress >= need) {
            d.rankProgress -= need; // излишек переносится на следующий ранг
            d.rank++;
        }
        d.normalize(); // на максимальном ранге прогресс обнуляется

        if (d.rank == oldRank) {
            // у демона «без ранга» своя подпись: сколько осталось до получения ранга
            String key = "vampire.message.progress." + source.key + (wasUnranked ? ".unranked" : "");
            Component msg = Component.translatable(key,
                    amount, d.rankProgress, d.rankUpProgress()).withStyle(factionColor(f));
            // кровь — над хотбаром (бывает часто); победы — в чат, чтобы их не затирало сообщение о крови в тот же тик
            if (source == Source.BLOOD) p.displayClientMessage(msg, true);
            else p.sendSystemMessage(msg);
            return;
        }

        restoreBloodFraction(d, frac);   // шкала крови выросла — доля заполнения та же
        VampireLogic.refreshStats(p);    // здоровье, урон и скорость нового ранга
        // первый ранг демона — «присвоен», а не «повышен»
        p.sendSystemMessage(Component.translatable(wasUnranked ? "vampire.message.rank_first" : "vampire.message.rank_up",
                Component.translatable(f.rankLangKey(d.rank))).withStyle(factionColor(f)));
        if (d.rankUpProgress() == 0) {
            p.sendSystemMessage(Component.translatable("vampire.message.rank_max").withStyle(ChatFormatting.GOLD));
        }
        p.playNotifySound(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.PLAYERS, 1f, 1f);
    }

    // ================= СМЕНА ФРАКЦИИ И РАНГА (команды) =================
    /**
     * Ставит фракцию (ранг становится начальным, прогресс 0). Демон получает тег вампира — без него механика демона
     * не работает; истребитель тег теряет; при «none» тег не трогаем (вампир без фракции остаётся вампиром).
     */
    public static void applyFaction(ServerPlayer p, Faction faction) {
        VampireData d = p.getAttachedOrCreate(VampireMod.DATA);
        double frac = bloodFraction(d);
        d.setFaction(faction);
        if (faction == Faction.DEMON) p.addTag(VampireMod.TAG);
        else if (faction == Faction.SLAYER) p.removeTag(VampireMod.TAG);
        restoreBloodFraction(d, frac);
        VampireLogic.refreshStats(p);
    }

    /** Ставит ранг внутри текущей фракции (прогресс 0). Диапазон проверяет вызывающий. */
    public static void applyRank(ServerPlayer p, int rank) {
        VampireData d = p.getAttachedOrCreate(VampireMod.DATA);
        double frac = bloodFraction(d);
        d.setRank(rank);
        restoreBloodFraction(d, frac);
        VampireLogic.refreshStats(p);
    }

    // ================= ХЕЛПЕРЫ =================
    private static double bloodFraction(VampireData d) {
        double max = d.maxBlood();
        return max > 0 ? d.blood / max : 1.0;
    }

    private static void restoreBloodFraction(VampireData d, double frac) {
        d.blood = d.maxBlood() * frac;
        d.normalize();
    }

    private static ChatFormatting factionColor(Faction f) {
        return f == Faction.SLAYER ? ChatFormatting.AQUA : ChatFormatting.RED;
    }
}
