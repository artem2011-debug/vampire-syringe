package com.vampiresyringe;

/**
 * Сколько прогресса ранга даёт каждое действие (Этап 5). Без зависимостей от Minecraft: цифры читаются из Cfg,
 * начисляет их RankProgress.
 *
 * Проверка баланса без запуска игры: {@code ProgressRewards.main} печатает таблицу по всем рангам.
 */
public final class ProgressRewards {
    private ProgressRewards() {}

    /** Демон: прогресс за поглощённую кровь (очки крови -> прогресс). 0 — если крови не поглощено. */
    public static int demonBlood(double bloodPoints) {
        if (bloodPoints <= 0) return 0;
        return Math.max(1, (int) Math.round(bloodPoints * Cfg.DEMON_PROGRESS_PER_BLOOD));
    }

    /** Демон ранга demonRank победил разбойника с клинком силы power (уровень зачарования, 0 — клинок без зачарования). */
    public static int banditKill(int power, int demonRank) {
        double base = Cfg.BANDIT_KILL_PROGRESS_BASE + Math.max(0, power) * Cfg.BANDIT_KILL_PROGRESS_PER_POWER;
        int r = Faction.DEMON.tableRank(demonRank);
        double mult = Math.max(Cfg.BANDIT_KILL_MIN_MULT, 1.0 - (r - 1) * Cfg.BANDIT_KILL_RANK_DECAY);
        return Math.max(1, (int) Math.round(base * mult));
    }

    /** Истребитель ранга slayerRank убил демона ранга demonRank: награда растёт с рангом демона, слабые цели режутся. */
    public static int slayerKill(int demonRank, int slayerRank) {
        int dr = Faction.DEMON.tableRank(demonRank); // демон «без ранга» стоит как ранг 1
        int sr = Faction.SLAYER.clampRank(slayerRank);
        double base = (double) Cfg.SLAYER_KILL_PROGRESS_PER_DEMON_RANK * dr;
        boolean weak = dr < sr * Cfg.SLAYER_RANK_DEMON_EQUIV_STEP - Cfg.SLAYER_WEAK_TARGET_MARGIN;
        return Math.max(1, (int) Math.round(weak ? base * Cfg.SLAYER_WEAK_TARGET_MULT : base));
    }

    /** java -cp <classes> com.vampiresyringe.ProgressRewards */
    public static void main(String[] args) {
        int villager = 6; // очков крови в жителе
        System.out.println("DEMON   ранг | порог | за жителя (оч. крови=" + villager + ") | жителей до ранга | разбойник сила 1 / 2 / 3 | разбойников (сила 2) до ранга");
        for (int r = 1; r <= Cfg.DEMON_MAX_RANK; r++) {
            int need = Faction.DEMON.rankUpProgress(r);
            int bite = demonBlood(villager);
            int b2 = banditKill(2, r);
            System.out.printf("  %2d | %5s | %3d | %5s | %3d / %3d / %3d | %5s%n", r,
                    need == 0 ? "макс" : String.valueOf(need), bite,
                    need == 0 ? "-" : String.valueOf((int) Math.ceil(need / (double) bite)),
                    banditKill(1, r), b2, banditKill(3, r),
                    need == 0 ? "-" : String.valueOf((int) Math.ceil(need / (double) b2)));
        }
        System.out.println("SLAYER  ранг | порог | убийств демона своего уровня (ранг демона = ранг*" + Cfg.SLAYER_RANK_DEMON_EQUIV_STEP + ") | награда | слабый демон (ранг 1): награда / убийств");
        for (int s = 1; s <= Cfg.SLAYER_MAX_RANK; s++) {
            int need = Faction.SLAYER.rankUpProgress(s);
            int equal = Math.min(Cfg.DEMON_MAX_RANK, s * Cfg.SLAYER_RANK_DEMON_EQUIV_STEP);
            int reward = slayerKill(equal, s);
            int weak = slayerKill(1, s);
            System.out.printf("  %2d | %5s | демон %2d | %3d | %3d / %5s | убийств равных: %5s%n", s,
                    need == 0 ? "макс" : String.valueOf(need), equal, reward, weak,
                    need == 0 ? "-" : String.valueOf((int) Math.ceil(need / (double) weak)),
                    need == 0 ? "-" : String.valueOf((int) Math.ceil(need / (double) reward)));
        }
    }
}
