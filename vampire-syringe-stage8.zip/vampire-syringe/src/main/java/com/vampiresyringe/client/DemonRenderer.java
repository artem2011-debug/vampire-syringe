package com.vampiresyringe.client;

import com.vampiresyringe.DemonMob;
import com.vampiresyringe.VampireMod;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ZombieRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.Zombie;

/** Этап 5: модель обычного зомби, но скин зависит от ранга демона-моба (DemonMob.skinTier). */
public class DemonRenderer extends ZombieRenderer {
    private static final ResourceLocation[] SKINS = {
            skin("demon_lower"), skin("demon_mid"), skin("demon_upper")
    };

    public DemonRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    private static ResourceLocation skin(String name) {
        return ResourceLocation.fromNamespaceAndPath(VampireMod.MOD_ID, "textures/entity/" + name + ".png");
    }

    @Override
    public ResourceLocation getTextureLocation(Zombie zombie) {
        if (zombie instanceof DemonMob demon) return SKINS[demon.skinTier()];
        return super.getTextureLocation(zombie);
    }
}
