package com.vampiresyringe.client;

import com.vampiresyringe.BloodScale;
import com.mojang.blaze3d.platform.InputConstants;
import com.vampiresyringe.Cfg;
import com.vampiresyringe.DevourFlashPayload;
import com.vampiresyringe.Faction;
import com.vampiresyringe.RegenKeyPayload;
import com.vampiresyringe.VampireLogic;
import com.vampiresyringe.VampireMod;
import com.vampiresyringe.VampireStatePayload;
import com.vampiresyringe.Vitality;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

import java.util.Map;

public class VampireClient implements ClientModInitializer {
    /**
     * Состояние, которое сервер сообщил этому клиенту: вампир ли он, фракция, ранг, прогресс, таймер горения.
     * Люди видят обычную полоску голода, вампиры — капли крови (длина шкалы зависит от фракции и ранга).
     */
    private static VampireStatePayload state = VampireStatePayload.HUMAN;

    /**
     * Клавиша быстрой регенерации: по умолчанию «B», переназначается в Настройки -> Управление (категория «Demon Syringe»).
     * Раньше лечил присед — теперь Shift нужен для поедания (Shift + ПКМ по существу).
     */
    private static KeyMapping regenKey;
    /** Что клиент последним сообщил серверу про клавишу регенерации (шлём только при смене). */
    private static boolean regenSent = false;

    /** Текущая плавная непрозрачность затемнения «самочувствия» 0..1 (см. Vitality). */
    private static double darkness = 0;
    /** Красноватая вспышка при поедании: сколько тиков осталось и сколько их было всего. */
    private static int flashTicks = 0;
    private static int flashTotal = 0;

    // ----- спрайты -----
    private static final ResourceLocation FOOD_EMPTY = vanilla("hud/food_empty");
    private static final ResourceLocation FOOD_EMPTY_HUNGER = vanilla("hud/food_empty_hunger");
    private static final ResourceLocation BLOOD_EMPTY = blood("hud/blood_empty");
    private static final ResourceLocation BLOOD_HALF = blood("hud/blood_half");
    private static final ResourceLocation BLOOD_FULL = blood("hud/blood_full");
    private static final ResourceLocation BLOOD_EMPTY_HUNGER = blood("hud/blood_empty_hunger");
    private static final ResourceLocation BLOOD_HALF_HUNGER = blood("hud/blood_half_hunger");
    private static final ResourceLocation BLOOD_FULL_HUNGER = blood("hud/blood_full_hunger");

    /** Ванильный спрайт полоски голода -> спрайт капли крови из этого мода (используется миксином). */
    public static final Map<ResourceLocation, ResourceLocation> BLOOD_SPRITES = Map.of(
            vanilla("hud/food_empty"), BLOOD_EMPTY,
            vanilla("hud/food_half"), BLOOD_HALF,
            vanilla("hud/food_full"), BLOOD_FULL,
            vanilla("hud/food_empty_hunger"), BLOOD_EMPTY_HUNGER,
            vanilla("hud/food_half_hunger"), BLOOD_HALF_HUNGER,
            vanilla("hud/food_full_hunger"), BLOOD_FULL_HUNGER
    );

    // ----- геометрия ванильной полоски голода -----
    private static final int ICON_SIZE = 9;
    private static final int ICON_STEP_X = 8;   // иконки идут справа налево с шагом 8
    private static final int ROW_STEP_Y = 10;   // дополнительные ряды капель — выше первого
    /** x предыдущей нарисованной ванилью «пустой» иконки; по нему узнаём начало новой полоски. */
    private static int lastEmptyX = Integer.MIN_VALUE;

    // ----- подпись фракции и ранга (Этап 5) -----
    private static final int HUD_MARGIN = 4;       // отступ от правого и нижнего края экрана
    private static final int HUD_LINE_HEIGHT = 10;
    private static final int COLOR_DEMON = 0xFFFF5555;
    private static final int COLOR_SLAYER = 0xFF55FFFF;
    private static final int COLOR_RANK = 0xFFFFFFFF;
    private static final int COLOR_PROGRESS = 0xFFAAAAAA;

    // ----- шкала концентрации истребителя -----
    private static final int CONC_WIDTH = 182;         // как у хотбара: ровно над полосками здоровья и еды
    private static final int CONC_HEIGHT = 5;
    private static final int CONC_GAP = 3;             // зазор между шкалой и верхним рядом (сердца/броня)
    private static final int CONC_SEGMENTS = 10;       // деления шкалы
    private static final int CONC_COLOR_FRAME = 0xFF000000;
    private static final int CONC_COLOR_EMPTY = 0xFF1B2A33;
    private static final int CONC_COLOR_FILL = 0xFF3FD0E6;
    private static final int CONC_COLOR_SHINE = 0xFF9AF2FF;
    private static final int CONC_COLOR_TICK = 0xFF0E161B;

    private static ResourceLocation vanilla(String path) {
        return ResourceLocation.withDefaultNamespace(path);
    }

    private static ResourceLocation blood(String path) {
        return ResourceLocation.fromNamespaceAndPath(VampireMod.MOD_ID, path);
    }

    // ----- доступ к состоянию (только чтение, источник истины — сервер) -----
    public static boolean isVampire() {
        return state.vampire();
    }

    /** Капли крови вместо окорочков: у демона (и вампира без фракции) да, у истребителя — никогда, у него обычная полоска еды. */
    public static boolean showsBloodBar() {
        return state.vampire() && state.faction() != Faction.SLAYER;
    }

    public static Faction faction() {
        return state.faction();
    }

    public static int rank() {
        return state.rank();
    }

    public static int rankProgress() {
        return state.rankProgress();
    }

    public static int sunBurnTicks() {
        return state.sunBurnTicks();
    }

    /** Максимум крови в очках при текущих фракции и ранге. */
    public static double maxBlood() {
        return state.maxBlood();
    }

    // ----- отрисовка шкалы крови (вызывается из GuiGraphicsMixin) -----
    public static boolean isHungerSprite(ResourceLocation sprite) {
        return FOOD_EMPTY_HUNGER.equals(sprite);
    }

    /**
     * Ваниль для каждой из 10 иконок сначала рисует «пустую» (справа налево, шаг 8 px), затем полную/половинку.
     * Новая полоска начинается там, где «пустая» иконка стоит НЕ на 8 px левее предыдущей.
     * Так не нужно знать размеры окна и ничего не ломается при смене масштаба интерфейса.
     */
    public static boolean isBarStart(ResourceLocation sprite, int x) {
        if (!FOOD_EMPTY.equals(sprite) && !FOOD_EMPTY_HUNGER.equals(sprite)) return false;
        boolean start = lastEmptyX - x != ICON_STEP_X;
        lastEmptyX = x;
        return start;
    }

    /**
     * Рисует шкалу крови: максимум по рангу, капли по HUD_DROPS_PER_ROW в ряд, первый ряд — на месте ванильной
     * полоски (x0, y0 — позиция самой правой иконки), следующие ряды — выше.
     * Текущая кровь = уровень голода (его синхронизирует ваниль, см. VampireLogic.syncFood).
     */
    public static void renderBloodBar(GuiGraphics g, int x0, int y0, boolean hunger) {
        Player player = Minecraft.getInstance().player;
        if (player == null) return;

        int step = Cfg.BLOOD_POINTS_PER_DROP;
        int drops = BloodScale.maxDrops(state.faction(), state.rank());
        int max = drops * step;
        int cur = Mth.clamp(player.getFoodData().getFoodLevel(), 0, max);
        int perRow = Cfg.HUD_DROPS_PER_ROW;

        // Под водой над полоской голода рисуются пузырьки воздуха — дополнительные ряды поднимаем выше них
        boolean bubbles = player.isEyeInFluid(FluidTags.WATER) || player.getAirSupply() < player.getMaxAirSupply();
        int extraRowShift = bubbles ? ROW_STEP_Y : 0;

        ResourceLocation empty = hunger ? BLOOD_EMPTY_HUNGER : BLOOD_EMPTY;
        ResourceLocation half = hunger ? BLOOD_HALF_HUNGER : BLOOD_HALF;
        ResourceLocation full = hunger ? BLOOD_FULL_HUNGER : BLOOD_FULL;

        for (int i = 0; i < drops; i++) {
            int row = i / perRow;
            int col = i % perRow;
            int x = x0 - col * ICON_STEP_X;
            int y = y0 - row * ROW_STEP_Y - (row > 0 ? extraRowShift : 0);

            g.blitSprite(empty, x, y, ICON_SIZE, ICON_SIZE);
            int fill = cur - i * step; // очков крови в этой капле
            if (fill >= step) {
                g.blitSprite(full, x, y, ICON_SIZE, ICON_SIZE);
            } else if (fill >= step / 2) {
                g.blitSprite(half, x, y, ICON_SIZE, ICON_SIZE);
            }
        }
    }

    /**
     * Этап 5: в правом нижнем углу — фракция, название ранга и прогресс до следующего (у истребителя шкалы крови нет,
     * поэтому подпись рисуется независимо от неё). Данные приходят в VampireStatePayload; у игрока без фракции подписи нет.
     */
    private static void renderFactionHud(GuiGraphics g) {
        if (!Cfg.HUD_SHOW_FACTION) return;
        Faction faction = state.faction();
        if (faction == Faction.NONE) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;

        int rank = state.rank();
        int need = faction.rankUpProgress(rank);
        Component factionLine = Component.translatable("vampire.hud.faction", Component.translatable(faction.langKey()));
        Component rankLine = Component.translatable("vampire.hud.rank", Component.translatable(faction.rankLangKey(rank)));
        Component progressLine = need <= 0
                ? Component.translatable("vampire.hud.progress.max")
                : faction.isUnranked(rank)
                        ? Component.translatable("vampire.hud.progress.unranked", state.rankProgress(), need)
                        : Component.translatable("vampire.hud.progress", state.rankProgress(), need);

        int y = g.guiHeight() - HUD_MARGIN - 8;
        drawRight(g, mc, progressLine, y, COLOR_PROGRESS);
        drawRight(g, mc, rankLine, y - HUD_LINE_HEIGHT, COLOR_RANK);
        drawRight(g, mc, factionLine, y - 2 * HUD_LINE_HEIGHT, faction == Faction.DEMON ? COLOR_DEMON : COLOR_SLAYER);
    }

    /**
     * Истребитель: над полосками здоровья и еды — шкала концентрации (пока декоративная: заполнена на
     * Cfg.SLAYER_CONCENTRATION_DECOR_FILL), ещё чуть выше — ранг истребителя, если он чего-то добился
     * (ранг выше Мизуноки или уже есть прогресс; Cfg.SLAYER_RANK_HUD_ALWAYS — показывать всегда).
     * Вместо капель крови у истребителя обычные окорочка — их рисует ваниль (см. showsBloodBar и миксин).
     * Высота подбирается под ванильную раскладку: сердца могут идти в несколько рядов (золотое сердце, больше 20 HP),
     * над ними — ряд брони, поэтому шкала всегда стоит над самым верхним рядом.
     */
    private static void renderSlayerHud(GuiGraphics g) {
        if (!Cfg.SLAYER_CONCENTRATION_BAR_SHOW || state.faction() != Faction.SLAYER) return;
        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        // там, где ваниль не рисует здоровье и еду (креатив, наблюдатель, F1), шкалы тоже нет
        if (player == null || mc.options.hideGui || mc.gameMode == null || !mc.gameMode.canHurtPlayer()) return;

        int heartRows = Mth.ceil((player.getMaxHealth() + Mth.ceil(player.getAbsorptionAmount())) / 2.0F / 10.0F);
        int rowStep = Math.max(10 - (heartRows - 2), 3);                  // как в ванильной Gui.renderPlayerHealth
        int top = g.guiHeight() - 39 - (heartRows - 1) * rowStep;         // верх самого верхнего ряда сердец
        if (player.getArmorValue() > 0) top -= ROW_STEP_Y;                // ряд брони выше сердец

        int x = g.guiWidth() / 2 - CONC_WIDTH / 2;
        int y = top - CONC_GAP - CONC_HEIGHT;
        int filled = Math.round(CONC_WIDTH * Mth.clamp(Cfg.SLAYER_CONCENTRATION_DECOR_FILL, 0f, 1f));

        g.fill(x - 1, y - 1, x + CONC_WIDTH + 1, y + CONC_HEIGHT + 1, CONC_COLOR_FRAME);
        g.fill(x, y, x + CONC_WIDTH, y + CONC_HEIGHT, CONC_COLOR_EMPTY);
        if (filled > 0) {
            g.fill(x, y, x + filled, y + CONC_HEIGHT, CONC_COLOR_FILL);
            g.fill(x, y, x + filled, y + 1, CONC_COLOR_SHINE);
        }
        for (int i = 1; i < CONC_SEGMENTS; i++) {
            int tx = x + CONC_WIDTH * i / CONC_SEGMENTS;
            g.fill(tx, y, tx + 1, y + CONC_HEIGHT, CONC_COLOR_TICK);
        }

        // ранг — только если слеер чего-то добился
        int rank = state.rank();
        if (Cfg.SLAYER_RANK_HUD_ALWAYS || rank > 1 || state.rankProgress() > 0) {
            Component rankName = Component.translatable(Faction.SLAYER.rankLangKey(rank));
            g.drawCenteredString(mc.font, rankName, g.guiWidth() / 2, y - 1 - CONC_GAP - mc.font.lineHeight, COLOR_SLAYER);
        }
    }

    private static void drawRight(GuiGraphics g, Minecraft mc, Component text, int y, int color) {
        g.drawString(mc.font, text, g.guiWidth() - HUD_MARGIN - mc.font.width(text), y, color, true);
    }

    /** ARGB: alpha 0..1 и цвет r,g,b. */
    private static int argb(double alpha, int r, int g, int b) {
        int a = (int) Math.round(Mth.clamp(alpha, 0.0, 1.0) * 255.0);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** Раз в тик: клавиша регенерации -> сервер, плавное затемнение по самочувствию, отсчёт красной вспышки. */
    private static void clientTick(Minecraft mc) {
        boolean pressed = mc.player != null && state.vampire() && mc.screen == null && regenKey.isDown();
        if (pressed != regenSent) {
            regenSent = pressed;
            if (ClientPlayNetworking.canSend(RegenKeyPayload.TYPE)) ClientPlayNetworking.send(new RegenKeyPayload(pressed));
        }

        // Самочувствие = меньшая из долей здоровья и крови (кровь = уровень голода, его синхронизирует ваниль). Хорошо — экран чистый,
        // половина шкал — темнее, пусто хотя бы на одной шкале — почти чёрный. Только у тех, у кого вместо еды капли крови.
        double target = 0;
        Player player = mc.player;
        if (player != null && showsBloodBar() && mc.gameMode != null && mc.gameMode.canHurtPlayer() && player.isAlive()) {
            double vitality = Vitality.of(player.getHealth(), player.getMaxHealth(), player.getFoodData().getFoodLevel(),
                    state.maxBlood(), Vitality.hpFloor(state.faction()));
            target = Vitality.darkness(vitality);
        }
        darkness += (target - darkness) * Cfg.VITALITY_DARKEN_SMOOTHING;
        if (Math.abs(target - darkness) < 0.002) darkness = target;

        if (flashTicks > 0) flashTicks--;
    }

    /**
     * Затемнение по самочувствию и красная вспышка при поедании. Вызывается из GuiMixin в самом НАЧАЛЕ Gui.render:
     * мир уже нарисован, а весь HUD (сердца, капли крови, хотбар, чат, подписи) рисуется позже — значит, он НЕ затемняется.
     * Затемнение мягкое: равномерная лёгкая дымка + виньетка по краям, центр экрана остаётся хорошо видимым.
     */
    public static void renderScreenTint(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui) return; // F1 — чистый экран
        int w = g.guiWidth(), h = g.guiHeight();
        if (darkness > 0.004) {
            g.fill(0, 0, w, h, argb(darkness * Cfg.VITALITY_DARKEN_MAX_ALPHA, 0, 0, 0));
            drawVignette(g, w, h, darkness * Cfg.VITALITY_VIGNETTE_MAX_ALPHA);
        }

        if (flashTicks > 0 && flashTotal > 0) {
            int elapsed = flashTotal - flashTicks;
            double fadeIn = Math.min(1.0, (elapsed + 1.0) / Cfg.DEVOUR_FLASH_FADE_IN_TICKS);
            double fadeOut = Math.min(1.0, flashTicks / (double) Cfg.DEVOUR_FLASH_FADE_OUT_TICKS);
            double alpha = Cfg.DEVOUR_FLASH_MAX_ALPHA * Math.min(fadeIn, fadeOut);
            g.fill(0, 0, w, h, argb(alpha, 190, 0, 0));
        }
    }

    /**
     * Виньетка: рамки-«кольца» от края экрана внутрь, каждое следующее прозрачнее (квадратичный спад).
     * Кольцо шириной step рисуется четырьмя прямоугольниками (верх, низ, лево, право без углов).
     */
    private static void drawVignette(GuiGraphics g, int w, int h, double maxAlpha) {
        if (maxAlpha < 0.004) return;
        int layers = Math.max(1, Cfg.VITALITY_VIGNETTE_LAYERS);
        int depth = (int) (Math.min(w, h) * Cfg.VITALITY_VIGNETTE_DEPTH);
        int step = Math.max(1, depth / layers);
        for (int i = 0; i < layers; i++) {
            int in = i * step;
            int x1 = in, y1 = in, x2 = w - in, y2 = h - in;
            if (x2 - x1 < 2 * step || y2 - y1 < 2 * step) break; // окно слишком маленькое
            double t = 1.0 - i / (double) layers;
            int color = argb(maxAlpha * t * t, 0, 0, 0);
            g.fill(x1, y1, x2, y1 + step, color);                 // верх
            g.fill(x1, y2 - step, x2, y2, color);                 // низ
            g.fill(x1, y1 + step, x1 + step, y2 - step, color);   // лево
            g.fill(x2 - step, y1 + step, x2, y2 - step, color);   // право
        }
    }

    @Override
    public void onInitializeClient() {
        // Этап 5: модели мобов
        EntityRendererRegistry.register(VampireMod.DEMON_MOB, DemonRenderer::new);
        EntityRendererRegistry.register(VampireMod.BANDIT, BanditRenderer::new);

        ClientPlayNetworking.registerGlobalReceiver(VampireStatePayload.TYPE, (payload, ctx) -> state = payload);
        ClientPlayNetworking.registerGlobalReceiver(DevourFlashPayload.TYPE, (payload, ctx) -> {
            flashTotal = Math.max(1, payload.ticks());
            flashTicks = flashTotal;
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            state = VampireStatePayload.HUMAN;
            lastEmptyX = Integer.MIN_VALUE;
            regenSent = false;
            darkness = 0;
            flashTicks = 0;
            flashTotal = 0;
        });

        // клавиша быстрой регенерации (по умолчанию B) — появляется в Настройки -> Управление
        regenKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.vampire.regen", InputConstants.Type.KEYSYM, InputConstants.KEY_B, "key.categories.vampire"));
        ClientTickEvents.END_CLIENT_TICK.register(VampireClient::clientTick);

        // Клиент сам знает, что он вампир «при смерти» (вампир с <= 2 сердцами, см. Cfg.LAST_STAND_HP),
        // поэтому ломание блоков и использование предметов отменяется сразу, без "призрачных" действий.
        // Серого экрана больше нет — это только игровое ограничение.
        VampireLogic.clientCrippled = () -> {
            Minecraft mc = Minecraft.getInstance();
            return state.vampire() && mc.player != null && !mc.player.isSpectator()
                    && mc.player.getHealth() > 0 && mc.player.getHealth() <= Cfg.LAST_STAND_HP;
        };

        // Затемнение рисует GuiMixin (под HUD), здесь — только подписи и шкала истребителя
        HudRenderCallback.EVENT.register((graphics, deltaTracker) -> {
            renderFactionHud(graphics); // Этап 5: фракция, ранг, прогресс
            renderSlayerHud(graphics);  // шкала концентрации и ранг истребителя
        });
    }
}
