package com.vampiresyringe.client;

import com.vampiresyringe.BanditMob;
import com.vampiresyringe.VampireMod;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Этап 5: обычная гуманоидная модель (как у зомби, но руки не подняты); меч в руке рисует стандартный слой предмета в руке. */
public class BanditRenderer extends HumanoidMobRenderer<BanditMob, HumanoidModel<BanditMob>> {
    private static final ResourceLocation SKIN =
            ResourceLocation.fromNamespaceAndPath(VampireMod.MOD_ID, "textures/entity/bandit.png");

    public BanditRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.ZOMBIE)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(BanditMob bandit) {
        return SKIN;
    }
}
