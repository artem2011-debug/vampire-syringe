package com.vampiresyringe;

/** Все настройки мода. */
public final class Cfg {
    private Cfg() {}

    // ===== ПРЕВРАЩЕНИЕ (эффект после укола) =====
    public static final int BOOST_SECONDS = 5;       // «Превращение» длится 5 секунд, потом демон сразу горит на солнце

    // ===== ЗДОРОВЬЕ И УРОН =====
    /**
     * Последнее сердце. Вампир НЕ МОЖЕТ умереть от урона: здоровье никогда не падает ниже этого значения,
     * любой урон на нём полностью игнорируется. Исключения для демона (Этап 3): солнце и оружие с зачарованием
     * «Испепеление солнца» убивают по-настоящему; смертельный урон от всего остального оставляет ему DEMON_DEATH_FLOOR_HP. Пока здоровье <= этого значения, вампир «при смерти»:
     * не ломает и не ставит блоки, не бьёт, не пользуется предметами — может только пить кровь (Shift + ПКМ) и лечиться клавишей регенерации.
     * (2 = одно сердце, 1 = половинка сердца.)
     */
    public static final float LAST_STAND_HP = 2f;
    public static final float LOW = 3f;              // порог «почти при смерти» (замедление и тошнота)

    // ===== КРОВЬ =====
    /** БАЗОВЫЙ максимум крови (ранг 1 / без фракции / слеер): 20 очков = 10 капель. Реальный максимум — BloodScale.maxBlood(). */
    public static final double MAX_BLOOD = 20;
    public static final double BLOOD_DRAIN_IDLE = 0.02;  // очков в секунду
    public static final double BLOOD_DRAIN_SPRINT = 0.08;
    public static final int FIST_COOLDOWN = 400;         // тиков, пока кровь с одной жертвы выпита (20 сек)
    public static final double HEAL_PER_BLOOD = 0.4;     // здоровья за 1 очко выпитой крови
    public static final double KILL_SHARE = 0.5;         // доля крови при убийстве оружием

    // ===== ШКАЛА КРОВИ: ШАГИ И МНОЖИТЕЛИ =====
    /** Шаг шкалы: сколько очков крови в одной капле. Должно быть чётным и >= 2 (половинка капли = шаг / 2). */
    public static final int BLOOD_POINTS_PER_DROP = 2;
    /** Демон: +N к множителю максимума за каждый ранг Низшего выше первого (ранги 2..6). */
    public static final double DEMON_LOWER_BLOOD_MULT_STEP = 0.10;
    /** Демон: +N к множителю максимума за каждый ранг Высшего (ранги 7..12) поверх множителя ранга 6. Этап 2: 0.20 -> 0.35 (ранг 12 = 72 очка = 36 капель). */
    public static final double DEMON_UPPER_BLOOD_MULT_STEP = 0.35;
    /** Множитель максимума крови для истребителя (0 крови не бывает, поэтому не меньше базового). */
    public static final double SLAYER_BLOOD_MULT = 1.0;
    /** Жёсткий потолок шкалы в HUD: капель в ряду * рядов. */
    public static final int HUD_DROPS_PER_ROW = 10;      // ширина ванильной полоски голода, лучше не менять
    public static final int HUD_MAX_ROWS = 4;
    public static final double MAX_BLOOD_CAP = (double) BLOOD_POINTS_PER_DROP * HUD_DROPS_PER_ROW * HUD_MAX_ROWS;

    // ===== БЫСТРАЯ РЕГЕНЕРАЦИЯ (клавиша, по умолчанию «B»; переназначается в настройках управления Майнкрафта) =====
    public static final double REGEN_FULL_SECONDS = 3.5;
    public static final double REGEN_BLOOD_FRACTION = 0.9;
    /** Сколько тиков клавиша должна быть зажата, прежде чем пойдёт лечение (раньше то же самое делал присед). */
    public static final int REGEN_HOLD_TICKS = 10;

    // ===== ПОЕДАНИЕ (Shift + ПКМ по существу) =====
    /**
     * Демон начинает «трапезу», нажав Shift + ПКМ по живому существу голой рукой, и ест его заживо, пока держит Shift:
     * за DEVOUR_BITES укусов с интервалом DEVOUR_BITE_INTERVAL_TICKS (4 * 10 = 40 тиков = 2 с) он забирает всю кровь существа
     * (она делится поровну между укусами), а последний укус добивает жертву. Отпустил Shift или отошёл дальше DEVOUR_RANGE — трапеза прервана.
     */
    public static final int DEVOUR_BITES = 4;
    public static final int DEVOUR_BITE_INTERVAL_TICKS = 10;
    public static final double DEVOUR_RANGE = 3.5;
    /** Доля максимального здоровья жертвы, которую снимает каждый НЕ последний укус (последний убивает). */
    public static final float DEVOUR_BITE_DAMAGE_FRACTION = 0.2f;
    /** Красноватая вспышка экрана при поедании: длительность (тиков, 40 = 2 с), нарастание, затухание и максимум непрозрачности (0..1). */
    public static final int DEVOUR_FLASH_TICKS = 40;
    public static final int DEVOUR_FLASH_FADE_IN_TICKS = 4;
    public static final int DEVOUR_FLASH_FADE_OUT_TICKS = 16;
    public static final float DEVOUR_FLASH_MAX_ALPHA = 0.38f;

    // ===== САМОЧУВСТВИЕ: ЗАТЕМНЕНИЕ ЭКРАНА И ЗАМЕДЛЕНИЕ =====
    /**
     * Самочувствие демона = МЕНЬШАЯ из двух долей: здоровье и кровь (см. Vitality). Хорошо = обе шкалы почти полные; если хоть одна
     * шкала пустая — самочувствие нулевое, даже когда вторая полная.
     * Затемнение: самочувствие >= COMFORT — экран чистый, ниже — темнеет по кривой (CURVE < 1 затемняет раньше), на нуле — почти чёрный.
     */
    public static final double VITALITY_DARKEN_COMFORT = 0.8;
    public static final double VITALITY_DARKEN_CURVE = 0.8;
    /**
     * Затемнение нужно, чтобы игрок ПОНЯЛ, что ему плохо и пора поесть, а не чтобы ослепить его: мир всегда виден.
     * Рисуется ПОД HUD (миксин в Gui), поэтому полоски здоровья и крови остаются яркими.
     * MAX_ALPHA — равномерное затемнение всего экрана при нулевом самочувствии (0 = нет, 1 = чёрный экран).
     * VIGNETTE_MAX_ALPHA — дополнительное затемнение по краям (виньетка), центр экрана остаётся светлее.
     * VIGNETTE_DEPTH — на какую долю меньшей стороны экрана виньетка заходит от края; LAYERS — плавность (больше = мягче, чуть дороже).
     */
    public static final float VITALITY_DARKEN_MAX_ALPHA = 0.40f;
    public static final float VITALITY_VIGNETTE_MAX_ALPHA = 0.60f;
    public static final float VITALITY_VIGNETTE_DEPTH = 0.35f;
    public static final int VITALITY_VIGNETTE_LAYERS = 14;
    /** Плавность: доля пути до целевой темноты, проходимая за тик (0.15 ~ 1 с на полный переход). */
    public static final double VITALITY_DARKEN_SMOOTHING = 0.15;
    /**
     * Замедление: самочувствие НИЖЕ значения из EXHAUST_SLOW_BELOW даёт «Замедление» с уровнем из EXHAUST_SLOW_AMP (0 = I, 4 = V = -75% скорости).
     * Пороги по убыванию. На пустой шкале демон еле ползёт, как бы много ни было второй шкалы. Скоростные баффы по рангу при этом отключаются.
     */
    public static final double[] EXHAUST_SLOW_BELOW = {0.30, 0.20, 0.10, 0.04};
    public static final int[] EXHAUST_SLOW_AMP = {0, 1, 2, 4};

    static {
        if (EXHAUST_SLOW_BELOW.length != EXHAUST_SLOW_AMP.length || DEVOUR_BITES < 1 || DEVOUR_BITE_INTERVAL_TICKS < 1
                || DEVOUR_FLASH_FADE_IN_TICKS + DEVOUR_FLASH_FADE_OUT_TICKS > DEVOUR_FLASH_TICKS) {
            throw new IllegalStateException("Cfg: неверные настройки поедания или замедления");
        }
    }

    // ===== УРОВЕНЬ ВАМПИРА =====
    public static final int[] LEVEL_XP = {0, 15, 45, 100, 180}; // опыт для уровней 1..5

    // ===== ФРАКЦИИ И РАНГИ =====
    /** Демон: ранги 1..6 = Низший 6..1, ранги 7..12 = Высший 6..1. */
    public static final int DEMON_MAX_RANK = 12;
    public static final int DEMON_LOWER_RANKS = 6;       // сколько рангов в «Низших»; ранг >= DEMON_LOWER_RANKS + 1 — Высший
    /** Истребитель: ранги 1..6 = Мизуноки, Каноки, Тсучиноки, Хиноки, Киноки, Хаширэс. */
    public static final int SLAYER_MAX_RANK = 6;

    /**
     * Прогресс, нужный для перехода с ранга N на N+1 (индекс = N - 1). Длина = MAX_RANK - 1.
     * Значения — заглушки для балансировки; сам набор прогресса появится на следующих этапах.
     */
    public static final int[] DEMON_RANK_UP_PROGRESS = {100, 150, 200, 300, 400, 600, 800, 1000, 1500, 2000, 3000};
    public static final int[] SLAYER_RANK_UP_PROGRESS = {100, 200, 400, 800, 1600};

    static {
        if (DEMON_RANK_UP_PROGRESS.length != DEMON_MAX_RANK - 1
                || SLAYER_RANK_UP_PROGRESS.length != SLAYER_MAX_RANK - 1
                || BLOOD_POINTS_PER_DROP < 2 || BLOOD_POINTS_PER_DROP % 2 != 0) {
            throw new IllegalStateException("Cfg: неверные размеры таблиц рангов или шаг шкалы крови");
        }
    }

    // ===== ЭТАП 2: ХАРАКТЕРИСТИКИ ПО РАНГАМ =====
    // Индекс массива = ранг - 1. Ранги демона: 1..3 = Низший 6..4, 4..6 = Низший 3..1, 7..8 = Высший 6..5, 9..12 = Высший 4..1.
    // Базовое здоровье игрока (20 HP) не трогаем: ниже — только БОНУС поверх него (модификатор атрибута).

    /** Демон: бонус к максимальному здоровью (HP). Итого: 20,22,24,26,29,32,36,40,46,52,60,70. */
    public static final double[] DEMON_MAX_HEALTH_BONUS = {0, 2, 4, 6, 9, 12, 16, 20, 26, 32, 40, 50};
    /** Демон: пассивная регенерация, HP в секунду (пока хватает крови и нет солнца). */
    public static final double[] DEMON_REGEN_HP_PER_SEC = {0.05, 0.08, 0.12, 0.18, 0.25, 0.35, 0.5, 0.7, 1.0, 1.5, 2.2, 3.0};
    /** Демон: сколько очков крови уходит на 1 HP пассивной регенерации. */
    public static final double[] DEMON_REGEN_BLOOD_PER_HP = {0.50, 0.45, 0.40, 0.35, 0.30, 0.28, 0.25, 0.22, 0.20, 0.18, 0.16, 0.15};
    /** Демон: доля шкалы крови, ниже которой пассивная регенерация не идёт (запас крови). 0 — достаточно любой крови. */
    public static final double[] DEMON_REGEN_MIN_BLOOD_FRAC = {0.30, 0.30, 0.25, 0.20, 0.15, 0.10, 0.05, 0.05, 0, 0, 0, 0};
    /** Демон: множитель скорости быстрой регенерации (клавиша, по умолчанию B) (Этап 1: полное лечение за REGEN_FULL_SECONDS; цена в крови не меняется). */
    public static final double[] DEMON_SNEAK_HEAL_MULT = {0.25, 0.30, 0.35, 0.45, 0.55, 0.65, 0.75, 0.85, 1, 1, 1, 1};
    /** Демон: с этого ранга выдаётся ночное зрение (вне солнца). Ниже — только во время «Превращения». */
    public static final int DEMON_NIGHT_VISION_FROM_RANK = 3;

    /** Истребитель: прибавка к итоговому урону (+0.30 = +30%), модификатор ADD_MULTIPLIED_TOTAL. Мизуноки..Хаширэс. */
    public static final double[] SLAYER_ATTACK_DAMAGE_MULT = {0, 0.04, 0.08, 0.14, 0.20, 0.30};
    /** Истребитель: прибавка к скорости атаки (+0.20 = +20% к базовым 4.0), модификатор ADD_MULTIPLIED_BASE. */
    public static final double[] SLAYER_ATTACK_SPEED_MULT = {0, 0.03, 0.06, 0.10, 0.15, 0.20};

    static {
        int d = DEMON_MAX_RANK, s = SLAYER_MAX_RANK;
        if (DEMON_MAX_HEALTH_BONUS.length != d || DEMON_REGEN_HP_PER_SEC.length != d
                || DEMON_REGEN_BLOOD_PER_HP.length != d || DEMON_REGEN_MIN_BLOOD_FRAC.length != d
                || DEMON_SNEAK_HEAL_MULT.length != d
                || SLAYER_ATTACK_DAMAGE_MULT.length != s || SLAYER_ATTACK_SPEED_MULT.length != s) {
            throw new IllegalStateException("Cfg: таблицы характеристик Этапа 2 должны быть по одной записи на ранг");
        }
    }

    // ===== СОЛНЦЕ (ЭТАП 3) =====
    /** Верхняя граница таймера горения (тиков). Любое значение в DEMON_SUN_BURN_TICKS должно в неё укладываться. */
    public static final int SUN_BURN_MAX_TICKS = 600;
    /** Шаг горения, тиков: урон и уменьшение таймера идут раз в столько тиков (равно периоду «медленного» цикла VampireLogic). */
    public static final int SUN_BURN_STEP_TICKS = 10;
    /** Демон: здоровье, на котором его оставляет любая смертельная гибель НЕ от солнца и НЕ от «Испепеления солнца». */
    public static final float DEMON_DEATH_FLOOR_HP = 1.0f;
    /** Демон-игрок: урон от солнца, HP в секунду. Ранг 1 — минимум, ранг 12 — максимум, между ними линейно (4..6 HP = 2..3 сердца). */
    public static final double DEMON_SUN_DAMAGE_PER_SEC_MIN = 4.0;
    public static final double DEMON_SUN_DAMAGE_PER_SEC_MAX = 6.0;
    /**
     * Демон-МОБ: урон от солнца, HP в секунду (тоже линейно по рангу 1..12). «По канону» солнце смертельно для любого демона
     * за считанные секунды: 5..8 HP/с = от ~4 с (Низший 6, 20 HP) до ~9 с (Высший 1, 70 HP) на прямом солнце.
     * Хочется мягче — уменьшай эти два числа; на игроков-демонов они не влияют.
     */
    public static final double DEMON_MOB_SUN_DAMAGE_PER_SEC_MIN = 5.0;
    public static final double DEMON_MOB_SUN_DAMAGE_PER_SEC_MAX = 8.0;
    /**
     * Демон: сколько тиков он ещё горит после ухода с солнца (индекс = ранг - 1). Чем выше ранг, тем дольше догорает.
     * Кратно SUN_BURN_STEP_TICKS. Итого догорание забирает 50..80% максимума HP (таблица — SunBurn.main); тушится водой или дождём.
     */
    public static final int[] DEMON_SUN_BURN_TICKS = {50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150, 160};
    /** id зачарования «Испепеление солнца» (data/vampire/enchantment/sun_incineration.json, Этап 4). */
    public static final String SUN_SLAYING_ENCHANT_ID = "sun_incineration";

    static {
        if (DEMON_SUN_BURN_TICKS.length != DEMON_MAX_RANK) {
            throw new IllegalStateException("Cfg: DEMON_SUN_BURN_TICKS должен содержать по одной записи на ранг демона");
        }
        for (int i = 0; i < DEMON_SUN_BURN_TICKS.length; i++) {
            int t = DEMON_SUN_BURN_TICKS[i];
            if (t <= 0 || t > SUN_BURN_MAX_TICKS || t % SUN_BURN_STEP_TICKS != 0 || (i > 0 && t <= DEMON_SUN_BURN_TICKS[i - 1])) {
                throw new IllegalStateException("Cfg: DEMON_SUN_BURN_TICKS должен строго расти, быть кратен шагу и не выше SUN_BURN_MAX_TICKS");
            }
        }
    }

    // ===== ЗАЧАРОВАНИЕ «ИСПЕПЕЛЕНИЕ СОЛНЦА» (ЭТАП 4) =====
    /** Максимальный уровень. ДОЛЖЕН совпадать с "max_level" в data/vampire/enchantment/sun_incineration.json. */
    public static final int SUN_INCINERATION_MAX_LEVEL = 3;
    /** Доп. урон по демону за удар (HP), уровни I..III; игнорирует броню. Не больше самого удара. */
    public static final float[] SUN_PIERCE_DAMAGE = {1.0f, 2.0f, 3.0f};
    /** Сколько тиков висит метка «Солнечная рана», уровни I..III (100 тиков = 5 с). */
    public static final int[] SUN_WOUND_TICKS = {100, 160, 240};
    /** Насколько метка режет пассивную регенерацию демона (0.5 = вдвое, 1.0 = полностью), уровни I..III. */
    public static final double[] SUN_WOUND_REGEN_CUT = {0.50, 0.75, 1.00};

    static {
        int n = SUN_INCINERATION_MAX_LEVEL;
        if (SUN_PIERCE_DAMAGE.length != n || SUN_WOUND_TICKS.length != n || SUN_WOUND_REGEN_CUT.length != n) {
            throw new IllegalStateException("Cfg: таблицы «Испепеления солнца» должны быть по одной записи на уровень");
        }
    }

    // ===== ПРОГРЕСС РАНГА (ЭТАП 5) =====
    // Сколько прогресса даёт каждое действие. Пороги рангов — DEMON_RANK_UP_PROGRESS / SLAYER_RANK_UP_PROGRESS выше.
    // Таблица баланса без запуска игры: ProgressRewards.main.

    /**
     * Новообращённый демон идёт «без ранга» (ранг 0) и получает Низший 6 (ранг 1), только когда наберёт столько прогресса.
     * Прогресс даёт поглощённая кровь (DEMON_PROGRESS_PER_BLOOD за очко) и убитые мобы (DEMON_UNRANKED_MOB_KILL_PROGRESS за моба;
     * разбойник даёт свою награду BANDIT_KILL_*). 60 = 20 очков (10 капель) крови = ~3 жителя, или ~8 мобов, или смесь.
     * Излишек переносится на ранг 1 -> 2.
     */
    public static final int DEMON_FIRST_RANK_PROGRESS = 60;
    /** Демон «без ранга»: прогресс за каждого убитого моба (кровь с него считается отдельно, если она у моба есть). */
    public static final int DEMON_UNRANKED_MOB_KILL_PROGRESS = 8;

    static {
        if (DEMON_FIRST_RANK_PROGRESS <= 0 || DEMON_UNRANKED_MOB_KILL_PROGRESS <= 0) {
            throw new IllegalStateException("Cfg: порог первого ранга и награда за моба должны быть > 0");
        }
    }

    /** Демон: прогресс за каждое ПОГЛОЩЁННОЕ очко крови (укус и доля крови при убийстве). Считается то, что реально влезло в шкалу. */
    public static final double DEMON_PROGRESS_PER_BLOOD = 3.0;
    /** Демон: победа над разбойником = BASE + сила клинка (уровень случайного зачарования) * PER_POWER. */
    public static final int BANDIT_KILL_PROGRESS_BASE = 25;
    public static final int BANDIT_KILL_PROGRESS_PER_POWER = 15;
    /** Демон: награда за разбойника падает на DECAY за каждый ранг выше первого, но не ниже MIN_MULT (сильному демону разбойники мелковаты). */
    public static final double BANDIT_KILL_RANK_DECAY = 0.05;
    public static final double BANDIT_KILL_MIN_MULT = 0.40;

    /** Истребитель: прогресс за убийство демона = PER_DEMON_RANK * ранг демона (1..12). */
    public static final int SLAYER_KILL_PROGRESS_PER_DEMON_RANK = 10;
    /** Истребитель: ранг N считается равным по силе демону ранга N * STEP (Мизуноки ~ Низший 5, Хаширэс ~ Высший 1). */
    public static final int SLAYER_RANK_DEMON_EQUIV_STEP = 2;
    /** Истребитель: демон слабее равного по силе больше чем на MARGIN рангов даёт лишь MULT от награды (против фарма слабых). */
    public static final int SLAYER_WEAK_TARGET_MARGIN = 3;
    public static final double SLAYER_WEAK_TARGET_MULT = 0.25;
    /** Истребитель получает прогресс и за убийство игрока-демона (по его рангу). */
    public static final boolean SLAYER_PROGRESS_FROM_DEMON_PLAYERS = true;

    // ----- Демоны-мобы (зомби с баффами и своим скином; ранг 1..12 как у игроков-демонов) -----
    public static final int DEMON_MOB_SPAWN_WEIGHT = 12;
    public static final int DEMON_MOB_SPAWN_MIN_GROUP = 1;
    public static final int DEMON_MOB_SPAWN_MAX_GROUP = 2;
    /** Вес выпадения ранга при появлении (индекс = ранг - 1): высшие ранги — большая редкость. */
    public static final int[] DEMON_MOB_RANK_WEIGHTS = {30, 22, 16, 11, 8, 5, 3, 2, 1, 1, 1, 1};
    /** Бонусы к базовым характеристикам зомби (индекс = ранг - 1). Здоровье и броня — ADD_VALUE, урон — ADD_VALUE, скорость — ADD_MULTIPLIED_BASE. */
    public static final double[] DEMON_MOB_HEALTH_BONUS = {0, 2, 4, 6, 9, 12, 16, 20, 26, 32, 40, 50};
    public static final double[] DEMON_MOB_DAMAGE_BONUS = {0, 0.5, 1, 1.5, 2, 3, 4, 5, 6, 7, 8, 10};
    public static final double[] DEMON_MOB_SPEED_MULT = {0, 0.02, 0.04, 0.06, 0.08, 0.10, 0.14, 0.18, 0.22, 0.26, 0.30, 0.35};
    public static final double[] DEMON_MOB_ARMOR_BONUS = {0, 0, 1, 1, 2, 2, 3, 4, 5, 6, 7, 8};
    // Горение демона-моба на солнце — то же, что у игрока-демона: SunBurn (урон по рангу + догорание), тушится водой и дождём.
    /** Скины демона-моба: до этого ранга включительно — скин 0, до второго числа — скин 1, выше — скин 2. */
    public static final int[] DEMON_MOB_SKIN_TIER_MAX_RANKS = {4, 8};

    // ----- Разбойники (меч со случайным зачарованием) -----
    public static final int BANDIT_SPAWN_WEIGHT = 10;
    public static final int BANDIT_SPAWN_MIN_GROUP = 1;
    public static final int BANDIT_SPAWN_MAX_GROUP = 3;
    public static final double BANDIT_MAX_HEALTH = 24.0;
    public static final double BANDIT_MOVE_SPEED = 0.27;
    /** Собственный урон разбойника без оружия; основной урон даёт меч в руке. */
    public static final double BANDIT_BASE_ATTACK = 0.5;
    public static final double BANDIT_FOLLOW_RANGE = 28.0;
    /** Мечи по порядку: деревянный, каменный, железный — и вес выпадения каждого. */
    public static final int[] BANDIT_SWORD_WEIGHTS = {50, 35, 15};
    /** Из этого списка берётся ОДНО случайное зачарование клинка. Неизвестные id пропускаются. */
    public static final String[] BANDIT_ENCHANT_POOL = {
            "minecraft:sharpness", "minecraft:fire_aspect", "minecraft:knockback", "minecraft:sweeping_edge",
            "minecraft:looting", "minecraft:unbreaking", "vampire:sun_incineration"
    };
    /** Уровень случайного зачарования: от 1 до min(этого значения, максимума самого зачарования). Он же «сила клинка». */
    public static final int BANDIT_ENCHANT_MAX_LEVEL = 3;
    /** Шанс, что меч выпадет из убитого разбойника (так можно получить меч с «Испепелением солнца»). */
    public static final float BANDIT_BLADE_DROP_CHANCE = 0.12f;

    // ----- HUD -----
    /** Показывать в углу экрана фракцию, ранг и прогресс. */
    public static final boolean HUD_SHOW_FACTION = true;
    /** Истребитель: шкала концентрации над полосками здоровья и еды (пока декоративная). */
    public static final boolean SLAYER_CONCENTRATION_BAR_SHOW = true;
    /** Насколько заполнена декоративная шкала концентрации, 0.0..1.0 (позже её заменит настоящее значение). */
    public static final float SLAYER_CONCENTRATION_DECOR_FILL = 1.0f;
    /**
     * Истребитель: ранг над шкалой концентрации показывается, только если он чего-то добился (ранг выше Мизуноки или уже есть
     * прогресс). true — показывать всегда, в том числе новичку Мизуноки без прогресса.
     */
    public static final boolean SLAYER_RANK_HUD_ALWAYS = false;

    static {
        int d = DEMON_MAX_RANK;
        int weightSum = 0;
        for (int w : DEMON_MOB_RANK_WEIGHTS) weightSum += w;
        int swordSum = 0;
        for (int w : BANDIT_SWORD_WEIGHTS) swordSum += w;
        if (DEMON_MOB_RANK_WEIGHTS.length != d || DEMON_MOB_HEALTH_BONUS.length != d || DEMON_MOB_DAMAGE_BONUS.length != d
                || DEMON_MOB_SPEED_MULT.length != d || DEMON_MOB_ARMOR_BONUS.length != d
                || DEMON_MOB_SKIN_TIER_MAX_RANKS.length != 2 || BANDIT_SWORD_WEIGHTS.length != 3
                || weightSum <= 0 || swordSum <= 0) {
            throw new IllegalStateException("Cfg: таблицы демонов-мобов и разбойников Этапа 5 заданы неверно");
        }
    }

    // ===== УКОЛ (временно, для проверки Этапа 1) =====
    /** Первый укол человеку без фракции делает его демоном ранга 1 (Низший 6). */
    public static final boolean SYRINGE_MAKES_DEMON = true;
    /** ОТЛАДКА: повторный укол демона повышает ранг на 1 (после 12 — снова 1). Для проверки шкалы крови. В релизе = false. */
    public static final boolean DEBUG_SYRINGE_RANK_UP = false;

    // ===== СПАСЕНИЕ ИЗ БЕЗДНЫ =====
    public static final double ABYSS_Y_OVERWORLD = -62;
    public static final double ABYSS_Y_OTHER = -20;
}
