package com.vampiresyringe;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.function.BooleanSupplier;

/** Вся игровая логика демона (исторически — «вампира»: id мода, тег и имена классов остались прежними). */
public final class VampireLogic {
    private VampireLogic() {}

    /** Ставится клиентом (VampireClient): «я сейчас вампир при смерти?» (считает сам по своему здоровью). На сервере всегда false. */
    public static BooleanSupplier clientCrippled = () -> false;

    // ================= ЭТАП 2: id модификаторов атрибутов =================
    // Фиксированные id: addOrReplacePermanentModifier заменяет модификатор с тем же id, поэтому дублей не бывает.
    // Постоянные (не transient) — чтобы при входе в мир здоровье выше 20 не обрезалось до загрузки модификаторов.
    private static final ResourceLocation MOD_MAX_HEALTH =
            ResourceLocation.fromNamespaceAndPath(VampireMod.MOD_ID, "rank_max_health");
    private static final ResourceLocation MOD_ATTACK_DAMAGE =
            ResourceLocation.fromNamespaceAndPath(VampireMod.MOD_ID, "rank_attack_damage");
    private static final ResourceLocation MOD_ATTACK_SPEED =
            ResourceLocation.fromNamespaceAndPath(VampireMod.MOD_ID, "rank_attack_speed");
    /** Длительность «медленного» цикла slowTick, секунд (он идёт раз в 10 тиков). */
    private static final double SLOW_TICK_SECONDS = 0.5;

    // ================= СКРЫТЫЕ БАФФЫ ПО УРОВНЯМ (индекс = уровень, 0 не используется) =================
    // Ночью действуют полностью, днём в тени — на 1 ступень слабее, на солнце — не действуют.
    // Иконок у них нет: на экране виден только единый эффект «Демонизм».
    private static final List<Map<Holder<MobEffect>, Integer>> LEVEL_BUFFS = List.of(
            Map.<Holder<MobEffect>, Integer>of(),
            Map.of(MobEffects.MOVEMENT_SPEED, 0),                                                           // 1
            Map.of(MobEffects.MOVEMENT_SPEED, 0, MobEffects.DAMAGE_BOOST, 0, MobEffects.JUMP, 0),           // 2
            Map.of(MobEffects.MOVEMENT_SPEED, 1, MobEffects.DAMAGE_BOOST, 0, MobEffects.JUMP, 0,
                    MobEffects.DIG_SPEED, 0),                                                               // 3
            Map.of(MobEffects.MOVEMENT_SPEED, 1, MobEffects.DAMAGE_BOOST, 1, MobEffects.JUMP, 1,
                    MobEffects.DIG_SPEED, 0),                                                               // 4
            Map.of(MobEffects.MOVEMENT_SPEED, 2, MobEffects.DAMAGE_BOOST, 1, MobEffects.JUMP, 1,
                    MobEffects.DIG_SPEED, 1)                                                                // 5
    );

    // ================= КРОВЬ В СУЩЕСТВАХ =================
    private static final Map<String, Integer> BLOOD_FIXED = Map.of(
            "minecraft:chicken", 1,            // 0,5 капли
            "minecraft:villager", 6,           // 3 капли
            "minecraft:wandering_trader", 6
    );
    private static final Set<String> NO_BLOOD = Set.of(
            "minecraft:armor_stand", "minecraft:zombie", "minecraft:husk", "minecraft:drowned",
            "minecraft:zombie_villager", "minecraft:skeleton", "minecraft:stray", "minecraft:bogged",
            "minecraft:wither_skeleton", "minecraft:wither", "minecraft:zombie_horse",
            "minecraft:skeleton_horse", "minecraft:zombified_piglin", "minecraft:zoglin",
            "minecraft:phantom", "minecraft:creeper", "minecraft:ghast", "minecraft:blaze",
            "minecraft:slime", "minecraft:magma_cube", "minecraft:iron_golem", "minecraft:snow_golem",
            "minecraft:copper_golem", "minecraft:shulker", "minecraft:ender_dragon", "minecraft:vex",
            "minecraft:allay", "minecraft:warden", "minecraft:breeze",
            "vampire:demon_mob" // Этап 5: демон-моб — зомби с рангом, крови в нём нет
    );

    // ================= СОСТОЯНИЕ (не сохраняется, живёт до перезапуска сервера) =================
    private static final Map<UUID, Integer> drained = new HashMap<>();     // id жертвы -> тик, до которого кровь выпита
    private static final Map<UUID, Boolean> sunCache = new HashMap<>();    // горит ли игрок сейчас (на солнце или догорает) — тогда лечения нет
    private static final Map<UUID, Integer> regenTicks = new HashMap<>();  // сколько тиков подряд зажата клавиша регенерации
    private static final Set<UUID> regenHeld = new HashSet<>();            // у кого сейчас зажата клавиша быстрой регенерации (шлёт клиент)
    private static final Map<UUID, Devour> devours = new HashMap<>();      // кто сейчас пожирает жертву
    private static final Set<UUID> crippled = new HashSet<>();             // кто сейчас «при смерти»
    private static final Set<UUID> foodBound = new HashSet<>();            // у кого полоска голода показывает кровь
    private static final Map<UUID, VampireStatePayload> stateShown = new HashMap<>(); // что клиент знает: раса, фракция, ранг…
    private static boolean rulesDone = false;
    private static int slowCounter = 0;

    /** Идущая трапеза: кого ест, сколько тиков прошло, сколько крови во всей жертве. */
    private static final class Devour {
        final UUID target;
        final double totalBlood;
        int ticks = 0;

        Devour(UUID target, double totalBlood) {
            this.target = target;
            this.totalBlood = totalBlood;
        }
    }

    // ================= РЕГИСТРАЦИЯ СОБЫТИЙ =================
    public static void register() {
        ServerLifecycleEvents.SERVER_STARTING.register(server -> {
            rulesDone = false;
            slowCounter = 0;
            drained.clear();
            sunCache.clear();
            regenTicks.clear();
            regenHeld.clear();
            devours.clear();
            crippled.clear();
            foodBound.clear();
            stateShown.clear();
        });
        ServerTickEvents.END_SERVER_TICK.register(VampireLogic::onServerTick);

        // «при смерти»: удар по существу запрещён (пить кровь можно — это Shift + ПКМ, см. onUseEntity)
        AttackEntityCallback.EVENT.register(VampireLogic::onAttack);
        UseEntityCallback.EVENT.register(VampireLogic::onUseEntity);
        // клиент сообщает, зажата ли клавиша быстрой регенерации
        ServerPlayNetworking.registerGlobalReceiver(RegenKeyPayload.TYPE, (payload, ctx) -> {
            UUID rid = ctx.player().getUUID();
            if (payload.held()) regenHeld.add(rid);
            else regenHeld.remove(rid);
        });
        AttackBlockCallback.EVENT.register(VampireLogic::onAttackBlock);
        UseBlockCallback.EVENT.register(VampireLogic::onUseBlock);
        UseItemCallback.EVENT.register(VampireLogic::onUseItem);
        PlayerBlockBreakEvents.BEFORE.register(VampireLogic::onBreakBlock);

        // бессмертие
        ServerLivingEntityEvents.ALLOW_DAMAGE.register(VampireLogic::allowDamage);
        ServerLivingEntityEvents.ALLOW_DEATH.register(VampireLogic::allowDeath);

        ServerLivingEntityEvents.AFTER_DEATH.register(VampireLogic::onDeath);

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            stateShown.remove(handler.getPlayer().getUUID()); // клиент заново получит всё состояние
            regenHeld.remove(handler.getPlayer().getUUID());
            refreshStats(handler.getPlayer());                // атрибуты по фракции/рангу сразу при входе
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            UUID id = handler.getPlayer().getUUID();
            stateShown.remove(id);
            sunCache.remove(id);
            regenTicks.remove(id);
            regenHeld.remove(id);
            devours.remove(id);
            crippled.remove(id);
            foodBound.remove(id);
        });
        // тег игрока после смерти не всегда переживает респавн — возвращаем сами
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            if (oldPlayer.getTags().contains(VampireMod.TAG)) newPlayer.addTag(VampireMod.TAG);
            stateShown.remove(newPlayer.getUUID());
            crippled.remove(newPlayer.getUUID());
            devours.remove(newPlayer.getUUID());
            regenHeld.remove(newPlayer.getUUID());
            // Этап 3: данные копируются при смерти вместе с таймером горения — на новом теле он не должен продолжаться
            VampireData respawned = newPlayer.getAttached(VampireMod.DATA);
            if (respawned != null) respawned.sunBurnTicks = 0;
            // новая сущность — модификаторов на ней нет: ставим заново, потом возвращаем здоровье
            refreshStats(newPlayer);
            newPlayer.setHealth(alive ? Math.min(oldPlayer.getHealth(), newPlayer.getMaxHealth())
                                      : newPlayer.getMaxHealth());
        });
    }

    // ================= ХЕЛПЕРЫ =================
    private static boolean isVampire(Entity e) {
        return e.getTags().contains(VampireMod.TAG);
    }

    private static boolean isDemon(VampireData d) {
        return d != null && d.faction == Faction.DEMON;
    }

    private static boolean isDemon(ServerPlayer p) {
        return isDemon(p.getAttached(VampireMod.DATA));
    }

    /** Здоровье, ниже которого вампир не опускается: демон — Cfg.DEMON_DEATH_FLOOR_HP (1.0F), остальные — последнее сердце. */
    private static float deathFloor(VampireData d) {
        return isDemon(d) ? Cfg.DEMON_DEATH_FLOOR_HP : Cfg.LAST_STAND_HP;
    }

    /** Скрытый эффект: частиц и иконки нет. */
    private static void fx(ServerPlayer p, Holder<MobEffect> effect, int amp, double sec) {
        p.addEffect(new MobEffectInstance(effect, (int) Math.round(sec * 20), amp, false, false, false));
    }

    private static void msg(ServerPlayer p, String text) {
        p.displayClientMessage(Component.literal(text), true);
    }

    private static boolean isNight(ServerPlayer p) {
        return !SunLight.isDaytime(p.level()); // в Незере и Энде солнца нет — там всегда «ночь»
    }

    private static boolean inSun(ServerPlayer p) {
        return SunLight.exposed(p); // день, не в воде и над головой нет блоков
    }

    private static void ensureRules(MinecraftServer server) {
        if (rulesDone) return;
        // Обычная регенерация выключается правилом мира (для всех игроков мира)
        server.getGameRules().getRule(GameRules.RULE_NATURAL_REGENERATION).set(false, server);
        rulesDone = true;
    }

    // ================= «ПРИ СМЕРТИ» =================
    /** Вампир на последнем сердце: на сервере смотрим здоровье, на клиенте — флаг из VampireClient. */
    private static boolean isCrippled(Player p, Level level) {
        if (level.isClientSide) return clientCrippled.getAsBoolean();
        return p instanceof ServerPlayer sp && isVampire(sp) && !sp.isSpectator()
                && sp.getHealth() > 0 && sp.getHealth() <= Cfg.LAST_STAND_HP;
    }

    private static InteractionResult onAttackBlock(Player p, Level w, InteractionHand hand, BlockPos pos, Direction dir) {
        return isCrippled(p, w) ? InteractionResult.FAIL : InteractionResult.PASS;
    }

    private static InteractionResult onUseBlock(Player p, Level w, InteractionHand hand, BlockHitResult hit) {
        return isCrippled(p, w) ? InteractionResult.FAIL : InteractionResult.PASS;
    }

    private static InteractionResultHolder<ItemStack> onUseItem(Player p, Level w, InteractionHand hand) {
        ItemStack stack = p.getItemInHand(hand);
        return isCrippled(p, w) ? InteractionResultHolder.fail(stack) : InteractionResultHolder.pass(stack);
    }

    private static boolean onBreakBlock(Level w, Player p, BlockPos pos, BlockState state, @Nullable BlockEntity be) {
        return !isCrippled(p, w);
    }

    // ================= БЕССМЕРТИЕ =================
    private static boolean allowDamage(LivingEntity entity, DamageSource source, float amount) {
        if (!(entity instanceof ServerPlayer p) || !isVampire(p)) return true;
        if (source.is(DamageTypes.GENERIC_KILL)) return true;  // команда /kill работает как обычно
        if (source.is(DamageTypes.STARVE)) return false;       // голод заменён кровью — от жажды не умирают
        // Этап 4: удар «Испепелением солнца» по демону — доп. урон и метка (применятся в конце тика)
        if (isDemon(p)) SunIncineration.onDemonHit(p, source, amount);
        // Этап 3: солнце и оружие с «Испепелением солнца» проходят сквозь бессмертие демона
        if (isDemon(p) && canKillDemon(p.level(), source)) return true;
        // на последнем сердце любой урон гасится полностью
        return p.getHealth() > Cfg.LAST_STAND_HP;
    }

    /**
     * Страховка: если удар всё же убивает (Варден и т.п.), смерти не будет — остаётся последнее сердце.
     * Этап 3: у демона смерть от солнца (и догорания) и от оружия с «Испепелением солнца» настоящая;
     * любая другая смертельная гибель оставляет ему Cfg.DEMON_DEATH_FLOOR_HP (1.0F).
     */
    private static boolean allowDeath(LivingEntity entity, DamageSource source, float amount) {
        if (!(entity instanceof ServerPlayer p) || !isVampire(p)) return true;
        if (source.is(DamageTypes.GENERIC_KILL)) return true;
        if (isDemon(p) && canKillDemon(p.level(), source)) return true;
        p.setHealth(deathFloor(p.getAttached(VampireMod.DATA)));
        return false;
    }

    // ================= ЭТАП 3: СОЛНЦЕ =================
    /** Единственный урон, который убивает демона: солнце/догорание либо оружие с зачарованием «Испепеление солнца». */
    private static boolean canKillDemon(Level level, DamageSource source) {
        return source.is(VampireMod.SUN_DAMAGE) || source.is(VampireMod.SUN_PIERCE) || isSunSlayingWeapon(level, source);
    }

    /** Оружие, которым нанесён урон (меч в руке, стрела с луком и т.п.), имеет «Испепеление солнца» (Этап 4: SunIncineration). */
    private static boolean isSunSlayingWeapon(Level level, DamageSource source) {
        return SunIncineration.enchantLevel(level, source) > 0;
    }

    /** Источник урона vampire:sun — им жгут и игроков-демонов, и демонов-мобов (DemonMob). */
    public static DamageSource sunSource(ServerLevel level) {
        return new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                .getHolderOrThrow(VampireMod.SUN_DAMAGE));
    }

    /**
     * Один шаг горения демона (раз в Cfg.SUN_BURN_STEP_TICKS тиков, из slowTick).
     * На солнце (день, небо над головой, нет защиты): sunBurnTicks обновляется до значения по рангу.
     * В тени: sunBurnTicks убывает, пока не дойдёт до 0 — демон догорает. Пока таймер > 0 или демон на солнце —
     * наносится урон DamageType vampire:sun (его не останавливает бессмертие, см. allowDamage/allowDeath) и идут частицы.
     * Защита: «Превращение», вода и дождь (тушат и догорание), творческий режим, наблюдатель.
     *
     * @return горит ли демон в этот момент (тогда лечение блокируется)
     */
    private static boolean sunBurnStep(ServerPlayer p, VampireData d, boolean sun, int boost) {
        if (boost > 0 || p.isCreative() || p.isSpectator() || p.isInWaterOrRain()) {
            d.sunBurnTicks = 0;
            return false;
        }
        int ticks = sun ? SunBurn.burnTicks(d.rank) : d.sunBurnTicks;
        if (ticks <= 0) {
            d.sunBurnTicks = 0;
            return false;
        }
        d.sunBurnTicks = sun ? ticks : Math.max(0, ticks - Cfg.SUN_BURN_STEP_TICKS);

        ServerLevel level = (ServerLevel) p.level();
        sunParticles(level, p, sun);
        p.hurt(sunSource(level), SunBurn.damagePerStep(d.rank));
        return true;
    }

    /** На солнце — больше огня, при догорании — больше дыма. */
    public static void sunParticles(ServerLevel level, Entity e, boolean direct) {
        double x = e.getX(), y = e.getY() + e.getBbHeight() * 0.5, z = e.getZ();
        level.sendParticles(ParticleTypes.FLAME, x, y, z, direct ? 10 : 4, 0.3, 0.5, 0.3, 0.02);
        level.sendParticles(ParticleTypes.LARGE_SMOKE, x, y + 0.3, z, direct ? 4 : 8, 0.3, 0.5, 0.3, 0.02);
        level.sendParticles(ParticleTypes.SMOKE, x, y + 0.5, z, 6, 0.3, 0.6, 0.3, 0.03);
    }

    /** Смерть демона-моба от солнца: тело рассыпается пеплом (облако пепла и дыма, шипение). */
    private static void ashBurst(ServerLevel level, Entity e) {
        double x = e.getX(), y = e.getY() + e.getBbHeight() * 0.5, z = e.getZ();
        level.sendParticles(ParticleTypes.ASH, x, y, z, 70, 0.4, 0.8, 0.4, 0.08);
        level.sendParticles(ParticleTypes.WHITE_ASH, x, y, z, 40, 0.4, 0.8, 0.4, 0.06);
        level.sendParticles(ParticleTypes.LARGE_SMOKE, x, y, z, 14, 0.3, 0.6, 0.3, 0.04);
        level.sendParticles(ParticleTypes.FLAME, x, y, z, 12, 0.3, 0.6, 0.3, 0.05);
        level.playSound(null, x, y, z, SoundEvents.FIRE_EXTINGUISH, SoundSource.HOSTILE, 1.0f, 0.8f);
    }

    // ================= ЭТАП 2: ХАРАКТЕРИСТИКИ ПО РАНГУ =================
    /**
     * Приводит атрибуты игрока к тому, что положено по фракции и рангу. Идемпотентна: можно звать сколько угодно раз
     * (вход в мир, респавн, укол, каждые полсекунды из тика) — модификатор с нашим id всегда один, лишние не копятся.
     * Если характеристик больше нет (сменили фракцию, сняли тег) — модификаторы снимаются, остаются ванильные 20 HP.
     */
    public static void refreshStats(ServerPlayer p) {
        VampireData d = p.getAttached(VampireMod.DATA);
        RankStats st = d == null ? RankStats.NONE : RankStats.of(isVampire(p), d.faction, d.rank);

        float oldMax = p.getMaxHealth();
        boolean wasFull = p.getHealth() >= oldMax - 0.01f;

        syncModifier(p, Attributes.MAX_HEALTH, MOD_MAX_HEALTH, st.maxHealthBonus(),
                AttributeModifier.Operation.ADD_VALUE);
        syncModifier(p, Attributes.ATTACK_DAMAGE, MOD_ATTACK_DAMAGE, st.attackDamageMult(),
                AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
        syncModifier(p, Attributes.ATTACK_SPEED, MOD_ATTACK_SPEED, st.attackSpeedMult(),
                AttributeModifier.Operation.ADD_MULTIPLIED_BASE);

        float max = p.getMaxHealth();
        if (max != oldMax && p.getHealth() > 0) {
            if (p.getHealth() > max) p.setHealth(max);       // максимум упал — не оставляем здоровье выше него
            else if (wasFull && max > oldMax) p.setHealth(max); // был полный запас — остаётся полным
        }
    }

    private static void syncModifier(ServerPlayer p, Holder<Attribute> attr, ResourceLocation id,
                                     double amount, AttributeModifier.Operation op) {
        AttributeInstance inst = p.getAttribute(attr);
        if (inst == null) return;
        AttributeModifier cur = inst.getModifier(id);
        if (amount == 0) {
            if (cur != null) inst.removeModifier(id);
            return;
        }
        if (cur != null && cur.operation() == op && Math.abs(cur.amount() - amount) < 1e-9) return; // уже стоит
        inst.addOrReplacePermanentModifier(new AttributeModifier(id, amount, op));
    }

    /** Пассивная регенерация демона: идёт на любом ранге, но только пока есть запас крови и нет солнца. */
    private static void passiveRegen(ServerPlayer p, VampireData d, RankStats st, boolean sun) {
        double rate = st.regenHpPerSec() * SunIncineration.regenFactor(p); // Этап 4: метка «Солнечная рана» режет скорость
        if (rate <= 0 || sun) return;
        float h = p.getHealth(), max = p.getMaxHealth();
        if (h <= 0 || h >= max - 0.01f) return;
        if (d.blood <= 0 || d.blood < d.maxBlood() * st.regenMinBloodFrac()) return; // нет запаса крови

        double hp = Math.min(rate * SLOW_TICK_SECONDS, max - h);
        double cost = hp * st.regenBloodPerHp();
        if (cost > d.blood) {            // крови хватает не на весь шаг — лечим на сколько хватит
            hp = d.blood / st.regenBloodPerHp();
            cost = d.blood;
        }
        p.setHealth((float) (h + hp));
        setBlood(d, d.blood - cost);
    }

    // ================= УРОВЕНЬ ВАМПИРА =================
    private static int getLevel(VampireData d) {
        return d.level >= 1 ? Math.min(d.level, Cfg.LEVEL_XP.length) : 1;
    }

    private static void addXp(ServerPlayer p, VampireData d, double pts) {
        d.xp += pts;
        int lvl = 1;
        for (int i = 0; i < Cfg.LEVEL_XP.length; i++) if (d.xp >= Cfg.LEVEL_XP[i]) lvl = i + 1;
        if (lvl > getLevel(d)) {
            d.level = lvl;
            p.sendSystemMessage(Component.literal("§4Уровень демона повышен: §c" + lvl));
            p.playNotifySound(SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1f, 1f);
        }
    }

    /** Единый видимый эффект: «Демонизм» (уровень 1 — без цифры, дальше II, III, IV, V). */
    private static void showVampirism(ServerPlayer p, int lvl) {
        MobEffectInstance cur = p.getEffect(VampireMod.VAMPIRISM);
        if (cur != null && cur.getAmplifier() == lvl - 1 && cur.isInfiniteDuration()) return;
        p.removeEffect(VampireMod.VAMPIRISM);
        p.addEffect(new MobEffectInstance(VampireMod.VAMPIRISM, MobEffectInstance.INFINITE_DURATION,
                lvl - 1, false, false, true));
    }

    // ================= КРОВЬ =================
    private static void setBlood(VampireData d, double v) {
        d.blood = Math.max(0, Math.min(d.maxBlood(), v));
    }

    /**
     * Уровень голода = текущая кровь в очках (1 капля = Cfg.BLOOD_POINTS_PER_DROP очков, может быть больше 20).
     * Саму шкалу на клиенте рисует VampireClient под максимум по рангу; ваниль синхронизирует уровень голода сама.
     */
    private static void syncFood(ServerPlayer p, VampireData d) {
        FoodData food = p.getFoodData();
        int points = (int) Math.round(Math.min(d.blood, d.maxBlood()));
        if (food.getFoodLevel() != points) food.setFoodLevel(points);
        if (food.getSaturationLevel() < 1f) food.setSaturation(20f); // чтобы полоска не дёргалась
        foodBound.add(p.getUUID());
    }

    private static int bloodPoints(Entity e, boolean allowDead) {
        if (e == null) return 0;
        if (!allowDead && !e.isAlive()) return 0;
        if (!(e instanceof LivingEntity le)) return 0;
        if (e instanceof Player || e instanceof ArmorStand) return 0;

        String id = BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).toString();
        if (NO_BLOOD.contains(id)) return 0;
        Integer fixed = BLOOD_FIXED.get(id);
        if (fixed != null) return fixed;
        if (e.getType().is(EntityTypeTags.UNDEAD)) return 0;

        return Math.max(1, Math.min(6, (int) Math.round(le.getMaxHealth() * 0.3)));
    }

    // ================= УДАР ПРИ «ПРИ СМЕРТИ» =================
    /** Удар кулаком больше не кусает (укус — Shift + ПКМ). Единственное, что делает этот обработчик: «при смерти» бить нельзя. */
    private static InteractionResult onAttack(Player player, Level world, InteractionHand hand,
                                              Entity target, @Nullable EntityHitResult hit) {
        if (world.isClientSide || !(player instanceof ServerPlayer p)) return InteractionResult.PASS;
        if (p.isSpectator() || !isVampire(p)) return InteractionResult.PASS;
        return isCrippled(p, world) ? InteractionResult.FAIL : InteractionResult.PASS;
    }

    // ================= ПОЕДАНИЕ: SHIFT + ПКМ ПО СУЩЕСТВУ =================
    /** Кровь и поедание — у демона и у вампира без фракции (капли на HUD); у истребителя этого нет. */
    private static boolean canDevour(ServerPlayer p) {
        if (!isVampire(p)) return false;
        VampireData d = p.getAttached(VampireMod.DATA);
        return d == null || d.faction != Faction.SLAYER;
    }

    /**
     * Shift + ПКМ голой рукой по живому существу с кровью — демон начинает его пожирать (идёт на сервере, клиенту ничего не нужно:
     * он пропускает клик как обычно, а ванильное действие — например, торговлю с жителем — отменяет возврат SUCCESS отсюда).
     * Без Shift или с предметом в руке всё работает как в ванили. Сам процесс — tickDevours.
     * Fabric зовёт этот обработчик и для INTERACT_AT, и для INTERACT: повторный вызов при уже идущей трапезе просто гасится.
     */
    private static InteractionResult onUseEntity(Player player, Level world, InteractionHand hand,
                                                 Entity target, @Nullable EntityHitResult hit) {
        if (world.isClientSide || !(player instanceof ServerPlayer p)) return InteractionResult.PASS;
        if (hand != InteractionHand.MAIN_HAND || p.isSpectator() || !p.isShiftKeyDown()) return InteractionResult.PASS;
        if (!canDevour(p) || !p.getMainHandItem().isEmpty()) return InteractionResult.PASS; // только голой рукой

        if (devours.containsKey(p.getUUID())) return InteractionResult.SUCCESS; // уже ест
        int blood = bloodPoints(target, false); // чем крупнее существо, тем больше крови
        if (blood <= 0) return InteractionResult.PASS; // не еда — обычное взаимодействие

        int now = p.getServer().getTickCount();
        Integer until = drained.get(target.getUUID());
        if (until != null && now < until) {
            msg(p, "§7Кровь уже выпита");
            return InteractionResult.SUCCESS;
        }
        VampireData d = p.getAttachedOrCreate(VampireMod.DATA);
        if (d.blood >= d.maxBlood() - 0.01) {
            msg(p, "§7Ты не голоден");
            return InteractionResult.SUCCESS;
        }

        devours.put(p.getUUID(), new Devour(target.getUUID(), blood));
        // кровь с жертвы считается выпитой с самого начала: убийство в конце трапезы (onDeath) не добавит «долю крови» второй раз
        drained.put(target.getUUID(), now + Cfg.FIST_COOLDOWN);
        ServerPlayNetworking.send(p, new DevourFlashPayload(Cfg.DEVOUR_FLASH_TICKS)); // красноватая вспышка экрана
        ((ServerLevel) world).playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.HONEY_DRINK, SoundSource.PLAYERS, 1f, 0.6f);
        return InteractionResult.SUCCESS;
    }

    /**
     * Каждый тик ведёт все трапезы. Трапеза идёт, пока демон держит Shift, рука пуста, жертва жива и рядом (Cfg.DEVOUR_RANGE).
     * Жертва не может убежать (сильное замедление) и не может драться (стоит на месте). Раз в Cfg.DEVOUR_BITE_INTERVAL_TICKS — укус.
     */
    private static void tickDevours(MinecraftServer server) {
        if (devours.isEmpty()) return;
        Iterator<Map.Entry<UUID, Devour>> it = devours.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Devour> en = it.next();
            Devour dv = en.getValue();
            ServerPlayer p = server.getPlayerList().getPlayer(en.getKey());
            if (p == null || !p.isAlive() || p.isSpectator() || !canDevour(p)) {
                it.remove();
                continue;
            }
            Entity t = ((ServerLevel) p.level()).getEntity(dv.target);
            if (!(t instanceof LivingEntity) || !t.isAlive()) { // жертва мертва или пропала — трапеза окончена
                it.remove();
                continue;
            }
            LivingEntity victim = (LivingEntity) t;
            if (!p.isShiftKeyDown() || !p.getMainHandItem().isEmpty() || p.distanceTo(victim) > Cfg.DEVOUR_RANGE) {
                msg(p, "§7Трапеза прервана");
                it.remove();
                continue;
            }

            dv.ticks++;
            // жертву держат на месте: идти и драться она не может
            if (dv.ticks == 1 || dv.ticks % Cfg.DEVOUR_BITE_INTERVAL_TICKS == 0) {
                victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,
                        Cfg.DEVOUR_BITE_INTERVAL_TICKS * 2, 6, false, false, false));
            }
            if (victim instanceof Mob mob) mob.getNavigation().stop();
            victim.setDeltaMovement(victim.getDeltaMovement().multiply(0.1, 1.0, 0.1));

            if (dv.ticks % Cfg.DEVOUR_BITE_INTERVAL_TICKS == 0) {
                int bite = dv.ticks / Cfg.DEVOUR_BITE_INTERVAL_TICKS;
                boolean last = bite >= Cfg.DEVOUR_BITES;
                devourBite(p, victim, dv, last);
                if (last) it.remove();
            }
        }
    }

    /** Один укус: демон получает долю крови жертвы и немного здоровья, жертва теряет здоровье; последний укус добивает. */
    private static void devourBite(ServerPlayer p, LivingEntity victim, Devour dv, boolean last) {
        ServerLevel level = (ServerLevel) p.level();
        VampireData d = p.getAttachedOrCreate(VampireMod.DATA);

        double share = dv.totalBlood / Cfg.DEVOUR_BITES;
        if (d.blood < d.maxBlood() - 0.01) { // шкала полна — кровь не влезает, но жертва всё равно съедается
            double before = d.blood;
            setBlood(d, before + share);
            double gained = d.blood - before; // сколько реально влезло в шкалу
            addXp(p, d, share);
            p.setHealth((float) Math.min(p.getMaxHealth(), p.getHealth() + share * Cfg.HEAL_PER_BLOOD));
            RankProgress.onBlood(p, d, gained); // Этап 5: прогресс ранга демона за поглощённую кровь
        }

        p.playNotifySound(SoundEvents.HONEY_DRINK, SoundSource.PLAYERS, 1f, 1f);
        level.sendParticles(
                new BlockParticleOption(ParticleTypes.BLOCK, Blocks.REDSTONE_BLOCK.defaultBlockState()),
                victim.getX(), victim.getY() + victim.getBbHeight() * 0.5, victim.getZ(), 14, 0.25, 0.35, 0.25, 0.05);

        // Урон идёт от имени демона (убийство засчитывается ему: прогресс «без ранга», onDeath), мимо брони жертвы
        victim.invulnerableTime = 0;
        float dmg = last
                ? Math.max(victim.getHealth(), victim.getMaxHealth()) * 2f
                : victim.getMaxHealth() * Cfg.DEVOUR_BITE_DAMAGE_FRACTION;
        victim.hurt(p.damageSources().indirectMagic(p, p), dmg);
    }

    /**
     * Убийство. Этап 5: прогресс ранга — истребителю за демона, демону за разбойника (RankProgress.onKill; убийце-истребителю
     * тег вампира не нужен). Дальше — как раньше: у вампира часть крови проливается, остальное достаётся ему.
     */
    private static void onDeath(LivingEntity dead, DamageSource source) {
        // по канону демон-моб, сгоревший на солнце, рассыпается пеплом (игроков-демонов это не касается)
        if (dead instanceof DemonMob && source.is(VampireMod.SUN_DAMAGE) && dead.level() instanceof ServerLevel sunLevel) {
            ashBurst(sunLevel, dead);
        }

        Entity killer = source.getEntity();
        if (!(killer instanceof ServerPlayer p)) return;

        boolean vampire = isVampire(p);
        RankProgress.onKill(p, dead, vampire);
        if (!vampire) return;

        Integer until = drained.get(dead.getUUID());
        if (until != null && p.getServer().getTickCount() < until) return; // кровь уже выпита ударом

        double pts = bloodPoints(dead, true) * Cfg.KILL_SHARE;
        if (pts <= 0) return;
        VampireData d = p.getAttachedOrCreate(VampireMod.DATA);
        double before = d.blood;
        setBlood(d, d.blood + pts);
        addXp(p, d, pts);
        RankProgress.onBlood(p, d, d.blood - before); // Этап 5: и эта кровь тоже считается
    }

    // ================= КЛИЕНТ ЗНАЕТ СВОЁ СОСТОЯНИЕ =================
    /**
     * Отправляет клиенту вампир ли он, его фракцию, ранг, прогресс и таймер горения — только при изменении
     * (сравнение по значению: VampireStatePayload — record). От этого зависят вид и длина шкалы крови.
     */
    private static void syncState(ServerPlayer p, VampireStatePayload state) {
        if (state.equals(stateShown.get(p.getUUID()))) return;
        stateShown.put(p.getUUID(), state);
        ServerPlayNetworking.send(p, state);
    }

    // ================= ГЛАВНЫЙ ТИК СЕРВЕРА =================
    private static void onServerTick(MinecraftServer server) {
        int now = server.getTickCount();
        boolean slow = now % 10 == 0; // «медленный» цикл — каждые полсекунды
        boolean sec = false;
        if (slow) {
            slowCounter++;
            sec = slowCounter % 2 == 0;
            if (slowCounter % 120 == 0) drained.values().removeIf(v -> v < now);
        }

        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            UUID id = p.getUUID();
            if (slow) refreshStats(p); // демон и истребитель; у остальных модификаторы снимаются
            if (!isVampire(p)) {
                // не вампир: данные (если есть, например у будущего истребителя) всё равно отдаём клиенту
                syncState(p, VampireStatePayload.of(false, p.getAttached(VampireMod.DATA)));
                // если тег сняли командой — гасим эффект и возвращаем обычный голод
                if (p.hasEffect(VampireMod.VAMPIRISM)) p.removeEffect(VampireMod.VAMPIRISM);
                if (foodBound.remove(id)) p.getFoodData().setFoodLevel(20);
                crippled.remove(id);
                regenHeld.remove(id);
                devours.remove(id);
                continue;
            }
            try {
                VampireData d = p.getAttachedOrCreate(VampireMod.DATA);
                if (slow) slowTick(p, d, sec);
                fastTick(p, d);
                syncState(p, VampireStatePayload.of(true, d)); // в конце тика: клиент видит уже итоговые значения
            } catch (Exception e) {
                VampireMod.LOGGER.error("Vampire tick failed for {}", p.getName().getString(), e);
            }
        }
        tickDevours(server);
    }

    // ----- каждые полсекунды -----
    private static void slowTick(ServerPlayer p, VampireData d, boolean sec) {
        ensureRules(p.getServer());
        UUID id = p.getUUID();

        d.normalize(); // поля в допустимых пределах (в т.ч. кровь не выше максимума ранга)

        // кровь убывает сама, на бегу — быстрее
        setBlood(d, d.blood - (p.isSprinting() ? Cfg.BLOOD_DRAIN_SPRINT : Cfg.BLOOD_DRAIN_IDLE) * 0.5);

        int boost = d.boost;
        boolean night = isNight(p);
        boolean sun = boost <= 0 && inSun(p);

        // Этап 3: демон горит на солнце и догорает в тени; остальные вампиры — как раньше (обычный огонь ниже)
        boolean wasAlive = p.isAlive();
        boolean burning = isDemon(d) ? sunBurnStep(p, d, sun, boost) : sun;
        sunCache.put(id, burning); // горит — не лечится ни клавишей регенерации, ни пассивной регенерацией
        if (wasAlive && !p.isAlive()) return; // сгорел: остальная логика не нужна

        float h = p.getHealth();
        boolean low = h <= Cfg.LOW;
        int lvl = getLevel(d);
        // самочувствие = меньшая из долей здоровья и крови; на нуле любой из шкал демон еле ползёт, даже если вторая полная
        int exhaustAmp = p.isCreative() || p.isSpectator() ? -1
                : Vitality.slowAmplifier(Vitality.of(h, p.getMaxHealth(), d.blood, d.maxBlood(), deathFloor(d)));
        RankStats st = RankStats.of(true, d.faction, d.rank);

        // пассивная регенерация по рангу (тратит кровь)
        passiveRegen(p, d, st, burning);

        // регенерации как эффекта больше нет (зелья, яблоки, маяк — всё мимо)
        p.removeEffect(MobEffects.REGENERATION);

        // единый эффект «Вампиризм» (уровень вампира)
        showVampirism(p, lvl);

        // какие скрытые эффекты нужны
        Map<Holder<MobEffect>, Integer> want = new HashMap<>();
        java.util.function.BiConsumer<Holder<MobEffect>, Integer> set = (eff, amp) -> {
            if (amp < 0) return;
            want.merge(eff, amp, Math::max);
        };

        if (boost > 0) {
            // «Превращение»: 5 секунд сильных баффов и тошноты, солнце не жжёт
            set.accept(MobEffects.DAMAGE_BOOST, 2);
            set.accept(MobEffects.MOVEMENT_SPEED, 2);
            set.accept(MobEffects.DIG_SPEED, 1);
            set.accept(MobEffects.JUMP, 1);
            set.accept(MobEffects.NIGHT_VISION, 0);
            fx(p, MobEffects.CONFUSION, 0, 1.5);
        } else if (sun) {
            set.accept(MobEffects.WEAKNESS, 1);
        } else {
            // баффы по уровню: ночью полностью, днём в тени — на ступень слабее
            Map<Holder<MobEffect>, Integer> table = LEVEL_BUFFS.get(Math.min(lvl, LEVEL_BUFFS.size() - 1));
            for (Map.Entry<Holder<MobEffect>, Integer> en : table.entrySet()) {
                set.accept(en.getKey(), night ? en.getValue() : en.getValue() - 1);
            }
            if (st.nightVision()) set.accept(MobEffects.NIGHT_VISION, 0); // по рангу (Cfg.DEMON_NIGHT_VISION_FROM_RANK)
        }

        if (low) {
            set.accept(MobEffects.MOVEMENT_SLOWDOWN, 1);
            fx(p, MobEffects.CONFUSION, 0, 1.5);
        }

        // жажда: почти нет крови — слабость
        if (d.blood < 2) {
            set.accept(MobEffects.WEAKNESS, 0);
            set.accept(MobEffects.MOVEMENT_SLOWDOWN, 0);
        }

        if (exhaustAmp >= 0) {
            want.remove(MobEffects.MOVEMENT_SPEED); // ускорение по рангу не должно гасить замедление
            set.accept(MobEffects.MOVEMENT_SLOWDOWN, exhaustAmp);
        }

        for (Map.Entry<Holder<MobEffect>, Integer> en : want.entrySet()) {
            fx(p, en.getKey(), en.getValue(), en.getKey().equals(MobEffects.NIGHT_VISION) ? 20 : 2);
        }

        // горение на солнце у вампира без фракции (обычный огонь: урон настоящий, но убить он не может);
        // демон горит по Этапу 3 (sunBurnStep), ванильный огонь ему не нужен
        if (sun && !isDemon(d)) p.igniteForSeconds(2);

        // сообщение над хотбаром — только во время «Превращения» (кровь теперь на полоске голода)
        if (boost > 0) {
            msg(p, "§4✦ Превращение §7· §c" + boost + " с");
            ((ServerLevel) p.level()).sendParticles(
                    new BlockParticleOption(ParticleTypes.BLOCK, Blocks.REDSTONE_BLOCK.defaultBlockState()),
                    p.getX(), p.getY() + 1, p.getZ(), 6, 0.3, 0.5, 0.3, 0.02);
        }

        if (sec && boost > 0) d.boost = boost - 1;
    }

    // ----- каждый тик -----
    private static void fastTick(ServerPlayer p, VampireData d) {
        UUID id = p.getUUID();
        ServerLevel level = (ServerLevel) p.level();

        // полоска голода = кровь
        syncFood(p, d);

        // спасение из бездны
        double limit = level.dimension() == Level.OVERWORLD ? Cfg.ABYSS_Y_OVERWORLD : Cfg.ABYSS_Y_OTHER;
        if (p.getY() <= limit) {
            rescueFromAbyss(p);
            return;
        }

        float h = p.getHealth();
        float maxHp = p.getMaxHealth();

        // ниже последнего сердца здоровье не опускается (у демона — ниже 1.0F); пока демон горит, подъём не нужен:
        // иначе подъём «съедал» бы часть урона от солнца
        float floor = deathFloor(d);
        if (h > 0 && h < floor && !(isDemon(d) && sunCache.getOrDefault(id, false))) {
            p.setHealth(floor);
            h = floor;
        }

        // «при смерти»: сообщаем один раз при входе в состояние
        if (h > 0 && h <= Cfg.LAST_STAND_HP) {
            if (crippled.add(id)) msg(p, "§4Ты при смерти §7— можешь только пить кровь");
        } else {
            crippled.remove(id);
        }

        // быстрая регенерация: только пока зажата клавиша (по умолчанию «B», переназначается в настройках управления)
        int held = regenHeld.contains(id) ? regenTicks.getOrDefault(id, 0) + 1 : 0;
        regenTicks.put(id, held);
        if (held < Cfg.REGEN_HOLD_TICKS || sunCache.getOrDefault(id, false) || h <= 0 || h >= maxHp - 0.01f) return;

        double blood = d.blood;
        if (blood <= 0) return;
        double costPerHp = (Cfg.MAX_BLOOD * Cfg.REGEN_BLOOD_FRACTION) / maxHp; // полное лечение = 90% шкалы крови
        double gain = maxHp / (Cfg.REGEN_FULL_SECONDS * 20)                     // здоровья за один тик
                * RankStats.of(true, d.faction, d.rank).sneakHealMult();         // Этап 2: слабее на низких рангах (имя — историческое: раньше лечил присед)
        gain = Math.min(gain, Math.min(maxHp - h, blood / costPerHp));
        if (gain > 0) {
            p.setHealth((float) (h + gain));
            setBlood(d, blood - gain * costPerHp);
        }
    }

    private static void rescueFromAbyss(ServerPlayer p) {
        MinecraftServer server = p.getServer();
        ServerLevel target;
        double x, y, z;

        BlockPos sp = p.getRespawnPosition();
        if (sp != null) {
            ResourceKey<Level> dimKey = p.getRespawnDimension();
            target = server.getLevel(dimKey);
            if (target == null) target = server.overworld();
            x = sp.getX() + 0.5;
            y = sp.getY() + 1;
            z = sp.getZ() + 0.5;
        } else {
            target = server.overworld();
            BlockPos ws = target.getSharedSpawnPos();
            x = ws.getX() + 0.5;
            y = ws.getY() + 1;
            z = ws.getZ() + 0.5;
        }

        p.teleportTo(target, x, y, z, p.getYRot(), p.getXRot());
        p.fallDistance = 0;
        p.setDeltaMovement(Vec3.ZERO);
        p.hurtMarked = true;
        fx(p, MobEffects.DAMAGE_RESISTANCE, 4, 20);
        fx(p, MobEffects.SLOW_FALLING, 0, 20);
    }
}
