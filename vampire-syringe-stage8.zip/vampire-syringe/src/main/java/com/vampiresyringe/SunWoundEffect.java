package com.vampiresyringe;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

/**
 * Этап 4: «Солнечная рана» — метка от удара оружием с «Испепелением солнца». Пока висит на демоне,
 * пассивная регенерация режется (см. SunIncineration.regenFactor). Уровень эффекта = уровень зачарования - 1.
 * Сама по себе ничего не делает: логику читает VampireLogic.passiveRegen.
 */
public class SunWoundEffect extends MobEffect {
    public SunWoundEffect() {
        super(MobEffectCategory.HARMFUL, 0xFF9A1F);
    }
}
