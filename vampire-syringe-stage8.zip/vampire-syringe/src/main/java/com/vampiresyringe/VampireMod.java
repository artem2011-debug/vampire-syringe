package com.vampiresyringe;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VampireMod implements ModInitializer {
    public static final String MOD_ID = "vampire";
    /** Тот же тег, что и раньше: /tag <игрок> add|remove vampire */
    public static final String TAG = "vampire";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final AttachmentType<VampireData> DATA = AttachmentRegistry.<VampireData>builder()
            .persistent(VampireData.CODEC)
            .copyOnDeath()
            .initializer(VampireData::new)
            .buildAndRegister(ResourceLocation.fromNamespaceAndPath(MOD_ID, "data"));

    /** Этап 3: урон от солнца и догорания (data/vampire/damage_type/sun.json). */
    public static final ResourceKey<DamageType> SUN_DAMAGE = ResourceKey.create(Registries.DAMAGE_TYPE,
            ResourceLocation.fromNamespaceAndPath(MOD_ID, "sun"));
    /** Этап 3: зачарование «Испепеление солнца» — только ссылка по id; само зачарование — data/vampire/enchantment/sun_incineration.json (Этап 4). */
    public static final ResourceKey<Enchantment> SUN_SLAYING_ENCHANTMENT = ResourceKey.create(Registries.ENCHANTMENT,
            ResourceLocation.fromNamespaceAndPath(MOD_ID, Cfg.SUN_SLAYING_ENCHANT_ID));

    /** Этап 4: доп. урон «Испепеления солнца» по демону (data/vampire/damage_type/sun_pierce.json). */
    public static final ResourceKey<DamageType> SUN_PIERCE = ResourceKey.create(Registries.DAMAGE_TYPE,
            ResourceLocation.fromNamespaceAndPath(MOD_ID, "sun_pierce"));

    public static Item SYRINGE;
    /** Единый эффект «Вампиризм»: уровень эффекта = уровень вампира. */
    public static Holder<MobEffect> VAMPIRISM;
    /** Этап 4: метка «Солнечная рана» — режет пассивную регенерацию демона. */
    public static Holder<MobEffect> SUN_WOUND;

    /** Этап 5: демон-моб (зомби с рангом, баффами и скином по рангу). */
    public static EntityType<DemonMob> DEMON_MOB;
    /** Этап 5: разбойник с мечом со случайным зачарованием. */
    public static EntityType<BanditMob> BANDIT;

    @Override
    public void onInitialize() {
        SYRINGE = Registry.register(
                BuiltInRegistries.ITEM,
                ResourceLocation.fromNamespaceAndPath(MOD_ID, "syringe"),
                new SyringeItem(new Item.Properties().stacksTo(16)));

        VAMPIRISM = Registry.registerForHolder(
                BuiltInRegistries.MOB_EFFECT,
                ResourceLocation.fromNamespaceAndPath(MOD_ID, "vampirism"),
                new VampirismEffect());

        SUN_WOUND = Registry.registerForHolder(
                BuiltInRegistries.MOB_EFFECT,
                ResourceLocation.fromNamespaceAndPath(MOD_ID, "sun_wound"),
                new SunWoundEffect());

        registerMobs();

        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES)
                .register(entries -> entries.accept(SYRINGE));

        PayloadTypeRegistry.playS2C().register(VampireStatePayload.TYPE, VampireStatePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(DevourFlashPayload.TYPE, DevourFlashPayload.CODEC);   // красная вспышка при поедании
        PayloadTypeRegistry.playC2S().register(RegenKeyPayload.TYPE, RegenKeyPayload.CODEC);         // клавиша быстрой регенерации

        VampireLogic.register();
        SunIncineration.register(); // Этап 4
        VampireCommand.register();  // Этап 5: /vampire setfaction, /vampire setrank
        LOGGER.info("Vampire Syringe loaded");
    }

    /** Этап 5: типы существ, их характеристики по умолчанию и естественное появление в Верхнем мире. */
    private static void registerMobs() {
        DEMON_MOB = Registry.register(BuiltInRegistries.ENTITY_TYPE,
                ResourceLocation.fromNamespaceAndPath(MOD_ID, "demon_mob"),
                EntityType.Builder.of(DemonMob::new, MobCategory.MONSTER)
                        .sized(0.6F, 1.95F).clientTrackingRange(8).build("demon_mob"));
        BANDIT = Registry.register(BuiltInRegistries.ENTITY_TYPE,
                ResourceLocation.fromNamespaceAndPath(MOD_ID, "bandit"),
                EntityType.Builder.of(BanditMob::new, MobCategory.MONSTER)
                        .sized(0.6F, 1.95F).clientTrackingRange(8).build("bandit"));

        FabricDefaultAttributeRegistry.register(DEMON_MOB, Zombie.createAttributes()); // демон — зомби; ранг добавляет модификаторы сам
        FabricDefaultAttributeRegistry.register(BANDIT, BanditMob.createAttributes());

        // обычные правила появления монстров: темнота, твёрдая земля, не в мирном режиме
        SpawnPlacements.register(DEMON_MOB, SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules);
        SpawnPlacements.register(BANDIT, SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules);

        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), MobCategory.MONSTER, DEMON_MOB,
                Cfg.DEMON_MOB_SPAWN_WEIGHT, Cfg.DEMON_MOB_SPAWN_MIN_GROUP, Cfg.DEMON_MOB_SPAWN_MAX_GROUP);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), MobCategory.MONSTER, BANDIT,
                Cfg.BANDIT_SPAWN_WEIGHT, Cfg.BANDIT_SPAWN_MIN_GROUP, Cfg.BANDIT_SPAWN_MAX_GROUP);
    }
}
