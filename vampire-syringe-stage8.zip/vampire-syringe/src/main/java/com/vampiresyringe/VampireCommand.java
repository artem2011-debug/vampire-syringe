package com.vampiresyringe;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.Collection;
import java.util.List;
import java.util.Locale;

/**
 * Команды для проверки (нужны права оператора, уровень 2). Работают под двумя именами: /demon (основное) и /vampire (прежнее).
 *   /demon setfaction <none|demon|slayer> [игроки]  — фракция; демон становится «без ранга» (0), истребитель — Мизуноки (1); прогресс 0
 *   /demon setrank <ранг> [игроки]                  — ранг внутри фракции (демон 0..12, где 0 = «без ранга»; истребитель 1..6), прогресс 0
 * Без указания игроков действуют на того, кто вводит команду. Подробности — RankProgress.applyFaction / applyRank.
 */
public final class VampireCommand {
    private VampireCommand() {}

    private static final List<String> FACTION_IDS = List.of(Faction.NONE.id, Faction.DEMON.id, Faction.SLAYER.id);

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(root("demon"));
            dispatcher.register(root("vampire")); // прежнее имя команды, чтобы старые команды и скрипты не сломались
        });
    }

    private static LiteralArgumentBuilder<CommandSourceStack> root(String name) {
        return Commands.literal(name)
                        .requires(src -> src.hasPermission(2))
                        .then(Commands.literal("setfaction")
                                .then(Commands.argument("faction", StringArgumentType.word())
                                        .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(FACTION_IDS, builder))
                                        .executes(ctx -> setFaction(ctx, List.of(ctx.getSource().getPlayerOrException())))
                                        .then(Commands.argument("targets", EntityArgument.players())
                                                .executes(ctx -> setFaction(ctx, EntityArgument.getPlayers(ctx, "targets"))))))
                        .then(Commands.literal("setrank")
                                .then(Commands.argument("rank", IntegerArgumentType.integer(0))
                                        .executes(ctx -> setRank(ctx, List.of(ctx.getSource().getPlayerOrException())))
                                        .then(Commands.argument("targets", EntityArgument.players())
                                                .executes(ctx -> setRank(ctx, EntityArgument.getPlayers(ctx, "targets"))))));
    }

    private static int setFaction(CommandContext<CommandSourceStack> ctx, Collection<ServerPlayer> targets) {
        CommandSourceStack src = ctx.getSource();
        String id = StringArgumentType.getString(ctx, "faction").toLowerCase(Locale.ROOT);
        if (!FACTION_IDS.contains(id)) {
            src.sendFailure(Component.translatable("vampire.command.unknown_faction", id));
            return 0;
        }
        Faction faction = Faction.byId(id);

        for (ServerPlayer target : targets) {
            RankProgress.applyFaction(target, faction);
            int rank = target.getAttachedOrCreate(VampireMod.DATA).rank;
            if (faction == Faction.NONE) {
                src.sendSuccess(() -> Component.translatable("vampire.command.setfaction.none", target.getDisplayName()), true);
            } else {
                src.sendSuccess(() -> Component.translatable("vampire.command.setfaction", target.getDisplayName(),
                        Component.translatable(faction.langKey()),
                        Component.translatable(faction.rankLangKey(rank))), true);
            }
        }
        return targets.size();
    }

    private static int setRank(CommandContext<CommandSourceStack> ctx, Collection<ServerPlayer> targets) {
        CommandSourceStack src = ctx.getSource();
        int rank = IntegerArgumentType.getInteger(ctx, "rank");
        int done = 0;

        for (ServerPlayer target : targets) {
            Faction faction = target.getAttachedOrCreate(VampireMod.DATA).faction;
            if (faction == Faction.NONE) {
                src.sendFailure(Component.translatable("vampire.command.no_faction", target.getDisplayName()));
                continue;
            }
            if (rank < faction.minRank() || rank > faction.maxRank) {
                src.sendFailure(Component.translatable("vampire.command.rank_out_of_range",
                        Component.translatable(faction.langKey()), faction.minRank(), faction.maxRank));
                continue;
            }
            RankProgress.applyRank(target, rank);
            src.sendSuccess(() -> Component.translatable("vampire.command.setrank", target.getDisplayName(),
                    Component.translatable(faction.langKey()),
                    Component.translatable(faction.rankLangKey(rank))), true);
            done++;
        }
        return done;
    }
}
