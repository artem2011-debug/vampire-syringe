package com.vampiresyringe;

import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.List;

/**
 * Этап 5: разбойник — человекоподобный враг с мечом, на клинке которого ОДНО случайное зачарование
 * (список — Cfg.BANDIT_ENCHANT_POOL, в нём есть и «Испепеление солнца»). Победа над ним даёт демону прогресс ранга:
 * чем сильнее клинок (уровень зачарования = «сила»), тем больше награда (ProgressRewards.banditKill).
 * Из убитого иногда выпадает сам меч (Cfg.BANDIT_BLADE_DROP_CHANCE).
 */
public class BanditMob extends Monster {
    private static final Item[] SWORDS = {Items.WOODEN_SWORD, Items.STONE_SWORD, Items.IRON_SWORD};

    /** Сила клинка: уровень случайного зачарования (0 — клинок без зачарования). Хранится в NBT, поэтому не зависит от судьбы меча в руке. */
    private int power;

    public BanditMob(EntityType<? extends BanditMob> type, Level level) {
        super(type, level);
        // вооружает только сервер; при загрузке из NBT оружие и сила перезапишутся сохранёнными
        if (!level.isClientSide) equipBlade(level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, Cfg.BANDIT_MAX_HEALTH)
                .add(Attributes.MOVEMENT_SPEED, Cfg.BANDIT_MOVE_SPEED)
                .add(Attributes.ATTACK_DAMAGE, Cfg.BANDIT_BASE_ATTACK)
                .add(Attributes.FOLLOW_RANGE, Cfg.BANDIT_FOLLOW_RANGE);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.1, false));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(6, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    public int getPower() {
        return power;
    }

    // ================= КЛИНОК =================
    private void equipBlade(Level level) {
        RandomSource random = getRandom();
        ItemStack blade = new ItemStack(pickSword(random));
        power = 0;

        Registry<Enchantment> registry = level.registryAccess().registryOrThrow(Registries.ENCHANTMENT);
        List<Holder.Reference<Enchantment>> pool = new ArrayList<>();
        for (String id : Cfg.BANDIT_ENCHANT_POOL) {
            ResourceLocation loc = ResourceLocation.tryParse(id);
            if (loc == null) continue;
            registry.getHolder(ResourceKey.create(Registries.ENCHANTMENT, loc)).ifPresent(pool::add);
        }
        if (!pool.isEmpty()) {
            Holder.Reference<Enchantment> pick = pool.get(random.nextInt(pool.size()));
            int max = Math.max(1, Math.min(Cfg.BANDIT_ENCHANT_MAX_LEVEL, pick.value().getMaxLevel()));
            int lvl = 1 + random.nextInt(max);
            blade.enchant(pick, lvl);
            power = lvl;
        }

        setItemSlot(EquipmentSlot.MAINHAND, blade);
        setDropChance(EquipmentSlot.MAINHAND, Cfg.BANDIT_BLADE_DROP_CHANCE);
    }

    /** Меч по весам Cfg.BANDIT_SWORD_WEIGHTS (деревянный / каменный / железный). */
    private static Item pickSword(RandomSource random) {
        int total = 0;
        for (int w : Cfg.BANDIT_SWORD_WEIGHTS) total += w;
        int roll = random.nextInt(Math.max(1, total));
        for (int i = 0; i < SWORDS.length; i++) {
            roll -= Cfg.BANDIT_SWORD_WEIGHTS[i];
            if (roll < 0) return SWORDS[i];
        }
        return SWORDS[0];
    }

    // ================= СОХРАНЕНИЕ =================
    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("BladePower", power);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("BladePower")) power = tag.getInt("BladePower");
    }
}
