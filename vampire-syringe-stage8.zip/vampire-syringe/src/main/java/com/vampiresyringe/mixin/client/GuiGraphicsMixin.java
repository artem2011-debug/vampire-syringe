package com.vampiresyringe.mixin.client;

import com.vampiresyringe.client.VampireClient;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Подмена полоски голода на шкалу крови — только у демона (у истребителя и человека — обычные окорочка). Ванильные текстуры не трогаем,
 * поэтому люди видят обычные «окорочка».
 *
 * Ванильная полоска рисует ровно 10 иконок, а у демона высокого ранга капель больше. Поэтому у вампира все
 * вызовы рисования иконок голода отменяются, а на первой иконке (самой правой — она задаёт позицию полоски)
 * VampireClient рисует шкалу целиком под текущий максимум крови. Если ваниль полоску не рисует
 * (креатив, езда на животном с сердцами), то вызовов нет — и наша шкала тоже не появляется.
 */
@Mixin(GuiGraphics.class)
public abstract class GuiGraphicsMixin {

    /** Полоска голода рисуется через blitSprite(спрайт, x, y, ширина, высота). */
    @Inject(
            method = "blitSprite(Lnet/minecraft/resources/ResourceLocation;IIII)V",
            at = @At("HEAD"),
            cancellable = true)
    private void vampire$drawBloodBar(ResourceLocation sprite, int x, int y, int width, int height, CallbackInfo ci) {
        if (!VampireClient.showsBloodBar()) return; // у истребителя — обычные окорочка
        if (!VampireClient.BLOOD_SPRITES.containsKey(sprite)) return; // не иконка голода — рисуем как обычно

        ci.cancel();
        if (VampireClient.isBarStart(sprite, x)) {
            VampireClient.renderBloodBar((GuiGraphics) (Object) this, x, y, VampireClient.isHungerSprite(sprite));
        }
    }
}
