package com.vampiresyringe.mixin.client;

import com.vampiresyringe.client.VampireClient;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Затемнение «самочувствия» рисуется в самом начале отрисовки интерфейса. К этому моменту мир уже нарисован,
 * а весь HUD (сердца, капли крови, хотбар, чат, подписи) ещё нет — поэтому темнеет только игровой мир, а HUD остаётся ярким.
 * Раньше затемнение рисовалось через HudRenderCallback (в конце), и закрывало и сам HUD.
 */
@Mixin(Gui.class)
public abstract class GuiMixin {

    @Inject(
            method = "render(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/client/DeltaTracker;)V",
            at = @At("HEAD"))
    private void vampire$drawVitalityTint(GuiGraphics graphics, DeltaTracker deltaTracker, CallbackInfo ci) {
        VampireClient.renderScreenTint(graphics);
    }
}
