package com.vampiresyringe;

/**
 * Фракция игрока.
 * Ранг: NONE — 0 (рангов нет); DEMON — 0 («без ранга»: новообращённый, пока не поглотил нужное число крови/мобов),
 * затем 1..12 (1..6 = Низший 6..1, 7..12 = Высший 6..1);
 * SLAYER — 1..6 (Мизуноки, Каноки, Тсучиноки, Хиноки, Киноки, Хаширэс).
 * Класс намеренно без зависимостей от Minecraft: им пользуются и сервер, и клиент.
 */
public enum Faction {
    NONE("none", 0, null),
    DEMON("demon", Cfg.DEMON_MAX_RANK, Cfg.DEMON_RANK_UP_PROGRESS),
    SLAYER("slayer", Cfg.SLAYER_MAX_RANK, Cfg.SLAYER_RANK_UP_PROGRESS);

    /** Строковый id — именно он пишется в NBT (порядок констант в enum на сохранения не влияет). */
    public final String id;
    public final int maxRank;
    private final int[] rankUpProgress;

    Faction(String id, int maxRank, int[] rankUpProgress) {
        this.id = id;
        this.maxRank = maxRank;
        this.rankUpProgress = rankUpProgress;
    }

    /** Наименьший допустимый ранг: 0 для NONE и для DEMON («без ранга»), 1 для истребителя. */
    public int minRank() {
        return maxRank == 0 || this == DEMON ? 0 : 1;
    }

    /** Демон, которому ранг ещё не присвоен (только что обращён). */
    public boolean isUnranked(int rank) {
        return this == DEMON && rank <= 0;
    }

    /**
     * Ранг для индексации таблиц характеристик (индекс = ранг - 1): демон «без ранга» считается рангом 1,
     * чтобы все таблицы (здоровье, кровь, солнце) работали без особых случаев.
     */
    public int tableRank(int rank) {
        return Math.max(1, clampRank(rank));
    }

    public int clampRank(int rank) {
        return Math.max(minRank(), Math.min(maxRank, rank));
    }

    /**
     * Прогресс, нужный для перехода на следующий ранг; 0 — если ранг максимальный (или фракции нет).
     * Для демона «без ранга» — Cfg.DEMON_FIRST_RANK_PROGRESS (сколько надо поглотить, чтобы получить ранг 1).
     */
    public int rankUpProgress(int rank) {
        if (rankUpProgress == null) return 0;
        if (isUnranked(rank)) return Cfg.DEMON_FIRST_RANK_PROGRESS;
        if (rank < 1 || rank >= maxRank) return 0;
        return rankUpProgress[rank - 1];
    }

    /** Высший демон (ранги 7..12). */
    public boolean isUpper(int rank) {
        return this == DEMON && rank > Cfg.DEMON_LOWER_RANKS;
    }

    /** Ключ перевода названия фракции. */
    public String langKey() {
        return "vampire.faction." + id;
    }

    /** Ключ перевода названия ранга («vampire.rank.demon.7» и т.д.); для NONE — ключ названия фракции. */
    public String rankLangKey(int rank) {
        return maxRank == 0 ? langKey() : "vampire.rank." + id + "." + clampRank(rank);
    }

    public static Faction byId(String id) {
        for (Faction f : values()) if (f.id.equals(id)) return f;
        return NONE;
    }

    public static Faction byOrdinal(int ordinal) {
        Faction[] all = values();
        return ordinal >= 0 && ordinal < all.length ? all[ordinal] : NONE;
    }
}
