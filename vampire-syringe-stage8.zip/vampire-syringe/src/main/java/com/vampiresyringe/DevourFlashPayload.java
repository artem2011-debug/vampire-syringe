package com.vampiresyringe;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Сервер -> клиент: демон начал поедать жертву — экран на {@code ticks} тиков становится красноватым и возвращается к норме. */
public record DevourFlashPayload(int ticks) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<DevourFlashPayload> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(VampireMod.MOD_ID, "devour_flash"));
    public static final StreamCodec<ByteBuf, DevourFlashPayload> CODEC =
            ByteBufCodecs.VAR_INT.map(DevourFlashPayload::new, DevourFlashPayload::ticks);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
