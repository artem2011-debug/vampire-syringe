package com.vampiresyringe;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.Level;
import net.minecraft.core.Holder;

/**
 * Этап 5: демон-моб — зомби с рангом 1..12 (как у игроков-демонов). Ранг определяет баффы (здоровье, урон, скорость, броня;
 * таблицы Cfg.DEMON_MOB_*) и скин (3 вида, см. skinTier). Ранг выпадает при появлении по весам Cfg.DEMON_MOB_RANK_WEIGHTS.
 * Истребитель получает за убийство прогресс ранга, зависящий от ранга демона (RankProgress.onKill).
 * По канону солнце для демона смертельно: под прямым солнцем он получает урон vampire:sun (SunBurn.mobDamagePerSecond: растёт с рангом) и
 * продолжает гореть после ухода в тень (догорание тоже по рангу); шлем не защищает, броня и сопротивление урону не помогают
 * (см. теги bypasses_*), вода и дождь тушат. Сгоревший рассыпается пеплом (VampireLogic.onDeath).
 * В Утопленника под водой не превращается, подкрепления из обычных зомби не зовёт.
 */
public class DemonMob extends Zombie {
    private static final EntityDataAccessor<Integer> DATA_RANK =
            SynchedEntityData.defineId(DemonMob.class, EntityDataSerializers.INT);

    // Фиксированные id: addOrReplacePermanentModifier заменяет модификатор с тем же id, дублей не бывает
    private static final ResourceLocation MOD_HEALTH = modId("demon_mob_health");
    private static final ResourceLocation MOD_DAMAGE = modId("demon_mob_damage");
    private static final ResourceLocation MOD_SPEED = modId("demon_mob_speed");
    private static final ResourceLocation MOD_ARMOR = modId("demon_mob_armor");
    /** ADD_MULTIPLIED_TOTAL -1 обнуляет шанс подкреплений (иначе урон от солнца каждые полсекунды звал бы обычных зомби на сложности «Сложно»). */
    private static final ResourceLocation MOD_NO_REINFORCEMENTS = modId("demon_mob_no_reinforcements");

    /** Сколько тиков демон-моб ещё догорает после ухода с солнца (на солнце держится на значении по рангу). */
    private int sunBurnTicks = 0;

    public DemonMob(EntityType<? extends DemonMob> type, Level level) {
        super(type, level);
        // ранг выбирает только сервер; при загрузке из NBT значение ниже перезапишется сохранённым
        if (!level.isClientSide) applyRank(pickRank(getRandom()), true);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_RANK, 1);
    }

    private static ResourceLocation modId(String path) {
        return ResourceLocation.fromNamespaceAndPath(VampireMod.MOD_ID, path);
    }

    // ================= РАНГ =================
    public int getDemonRank() {
        return Faction.DEMON.tableRank(entityData.get(DATA_RANK)); // у моба всегда 1..12
    }

    /** Номер скина по рангу: 0 — до Cfg.DEMON_MOB_SKIN_TIER_MAX_RANKS[0], 1 — до [1], 2 — выше. Нужен клиентскому рендереру. */
    public int skinTier() {
        int r = getDemonRank();
        if (r <= Cfg.DEMON_MOB_SKIN_TIER_MAX_RANKS[0]) return 0;
        return r <= Cfg.DEMON_MOB_SKIN_TIER_MAX_RANKS[1] ? 1 : 2;
    }

    /** Ставит ранг и баффы; heal — вылечить до нового максимума (при создании, но не при загрузке из NBT). */
    private void applyRank(int rank, boolean heal) {
        int r = Faction.DEMON.tableRank(rank);
        entityData.set(DATA_RANK, r);
        int i = r - 1;
        syncModifier(Attributes.MAX_HEALTH, MOD_HEALTH, Cfg.DEMON_MOB_HEALTH_BONUS[i], AttributeModifier.Operation.ADD_VALUE);
        syncModifier(Attributes.ATTACK_DAMAGE, MOD_DAMAGE, Cfg.DEMON_MOB_DAMAGE_BONUS[i], AttributeModifier.Operation.ADD_VALUE);
        syncModifier(Attributes.MOVEMENT_SPEED, MOD_SPEED, Cfg.DEMON_MOB_SPEED_MULT[i], AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        syncModifier(Attributes.ARMOR, MOD_ARMOR, Cfg.DEMON_MOB_ARMOR_BONUS[i], AttributeModifier.Operation.ADD_VALUE);
        syncModifier(Attributes.SPAWN_REINFORCEMENTS_CHANCE, MOD_NO_REINFORCEMENTS, -1.0, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
        if (heal) setHealth(getMaxHealth());
    }

    private void syncModifier(Holder<Attribute> attr, ResourceLocation id, double amount, AttributeModifier.Operation op) {
        AttributeInstance inst = getAttribute(attr);
        if (inst == null) return;
        if (amount == 0) {
            inst.removeModifier(id);
            return;
        }
        inst.addOrReplacePermanentModifier(new AttributeModifier(id, amount, op));
    }

    /** Случайный ранг по весам Cfg.DEMON_MOB_RANK_WEIGHTS. */
    private static int pickRank(RandomSource random) {
        int total = 0;
        for (int w : Cfg.DEMON_MOB_RANK_WEIGHTS) total += w;
        int roll = random.nextInt(Math.max(1, total));
        for (int i = 0; i < Cfg.DEMON_MOB_RANK_WEIGHTS.length; i++) {
            roll -= Cfg.DEMON_MOB_RANK_WEIGHTS[i];
            if (roll < 0) return i + 1;
        }
        return 1;
    }

    // ================= ПОВЕДЕНИЕ =================
    // Без @Override: имена и уровень доступа этих методов Zombie в разных версиях разные, а public их безопасно расширяет.
    /** Ванильное горение зомби отключено: оно щадит носителей шлема. Горение на солнце — в aiStep(), без исключений. */
    public boolean isSunSensitive() {
        return false;
    }

    /** Солнце жжёт демона независимо от шлема: свой шаг горения вместо ванильного поджога зомби. */
    @Override
    public void aiStep() {
        if (!level().isClientSide && isAlive()) sunStep();
        super.aiStep();
    }

    /**
     * Шаг горения, раз в Cfg.SUN_BURN_STEP_TICKS тиков — те же правила, что у игрока-демона (VampireLogic.sunBurnStep):
     * на прямом солнце таймер обновляется до значения по рангу, в тени убывает; пока он > 0 — урон vampire:sun и частицы пепла/огня.
     * Вода и дождь гасят всё сразу.
     */
    private void sunStep() {
        if (tickCount % Cfg.SUN_BURN_STEP_TICKS != 0) return;
        if (isInWaterOrRain()) {
            sunBurnTicks = 0;
            return;
        }
        int rank = getDemonRank();
        boolean sun = SunLight.exposed(this);
        int ticks = sun ? SunBurn.burnTicks(rank) : sunBurnTicks;
        if (ticks <= 0) {
            sunBurnTicks = 0;
            return;
        }
        sunBurnTicks = sun ? ticks : Math.max(0, ticks - Cfg.SUN_BURN_STEP_TICKS);

        ServerLevel serverLevel = (ServerLevel) level();
        VampireLogic.sunParticles(serverLevel, this, sun);
        // пепел сыплется с горящего демона-моба (по канону тело рассыпается пеплом)
        serverLevel.sendParticles(ParticleTypes.ASH, getX(), getY() + getBbHeight() * 0.5, getZ(), sun ? 14 : 8, 0.35, 0.6, 0.35, 0.03);
        hurt(VampireLogic.sunSource(serverLevel), SunBurn.mobDamagePerStep(rank));
    }

    /** Не превращается в Утопленника под водой. */
    public boolean convertsInWater() {
        return false;
    }

    /** В имени виден ранг: «Демон · Низший 6» (в сообщениях о смерти, над прицелом в творческом режиме и т.п.). */
    @Override
    public Component getTypeName() {
        return Component.translatable("entity.vampire.demon_mob.ranked",
                Component.translatable(Faction.DEMON.rankLangKey(getDemonRank())));
    }

    // ================= СОХРАНЕНИЕ =================
    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("DemonRank", getDemonRank());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("DemonRank")) applyRank(tag.getInt("DemonRank"), false);
    }
}
