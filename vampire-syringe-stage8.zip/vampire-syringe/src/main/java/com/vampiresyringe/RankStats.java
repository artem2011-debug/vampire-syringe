package com.vampiresyringe;

/**
 * Характеристики по фракции и рангу (Этап 2). Без зависимостей от Minecraft: цифры читаются из Cfg,
 * применяет их VampireLogic. Здоровье — только бонус поверх базовых 20 HP; для истребителя бонуса к здоровью нет.
 *
 * Проверка баланса без запуска игры: {@code RankStats.main} печатает таблицу по всем рангам.
 */
public record RankStats(double maxHealthBonus, double regenHpPerSec, double regenBloodPerHp,
                        double regenMinBloodFrac, double sneakHealMult, boolean nightVision,
                        double attackDamageMult, double attackSpeedMult) {

    /** Ничего не выдаётся (человек, либо демон с снятым тегом). */
    public static final RankStats NONE = new RankStats(0, 0, 0, 0, 1, false, 0, 0);
    /** Вампир без фракции (тег выдан командой): поведение как в Этапе 1 — ночное зрение, без бонусов. */
    public static final RankStats LEGACY_VAMPIRE = new RankStats(0, 0, 0, 0, 1, true, 0, 0);

    /**
     * @param vampire есть ли у игрока тег вампира (демон получает характеристики только вместе с ним,
     *                как и остальная механика демона; истребитель тега не требует)
     */
    public static RankStats of(boolean vampire, Faction faction, int rank) {
        int r = faction.tableRank(rank); // демон «без ранга» получает характеристики ранга 1
        if (faction == Faction.DEMON && vampire) {
            int i = r - 1;
            return new RankStats(
                    Cfg.DEMON_MAX_HEALTH_BONUS[i], Cfg.DEMON_REGEN_HP_PER_SEC[i], Cfg.DEMON_REGEN_BLOOD_PER_HP[i],
                    Cfg.DEMON_REGEN_MIN_BLOOD_FRAC[i], Cfg.DEMON_SNEAK_HEAL_MULT[i],
                    r >= Cfg.DEMON_NIGHT_VISION_FROM_RANK, 0, 0);
        }
        if (faction == Faction.SLAYER) {
            int i = r - 1;
            return new RankStats(0, 0, 0, 0, 1, false,
                    Cfg.SLAYER_ATTACK_DAMAGE_MULT[i], Cfg.SLAYER_ATTACK_SPEED_MULT[i]);
        }
        return vampire ? LEGACY_VAMPIRE : NONE;
    }

    // ================= ОТЧЁТ ДЛЯ БАЛАНСА =================
    /** java -cp <classes> com.vampiresyringe.RankStats */
    public static void main(String[] args) {
        System.out.println("DEMON   ранг | HP | кровь оч/капли | реген HP/с | кровь/HP | мин.кровь | полное лечение с 0 (с) | цена полного лечения (оч / % шкалы) | присед x");
        for (int r = 1; r <= Cfg.DEMON_MAX_RANK; r++) {
            RankStats s = of(true, Faction.DEMON, r);
            double hp = 20 + s.maxHealthBonus();
            double maxBlood = BloodScale.maxBlood(Faction.DEMON, r);
            double minBlood = maxBlood * s.regenMinBloodFrac();
            double seconds = (hp - Cfg.LAST_STAND_HP) / s.regenHpPerSec();
            double cost = (hp - Cfg.LAST_STAND_HP) * s.regenBloodPerHp();
            System.out.printf("  %2d | %4.0f | %3.0f / %2d | %5.2f | %4.2f | %4.1f | %7.0f | %5.1f / %3.0f%% | %.2f%n",
                    r, hp, maxBlood, BloodScale.maxDrops(Faction.DEMON, r), s.regenHpPerSec(), s.regenBloodPerHp(),
                    minBlood, seconds, cost, 100 * cost / maxBlood, s.sneakHealMult());
        }
        System.out.println("SLAYER  ранг | HP | урон x | скорость атаки (ед./с) | DPS x");
        for (int r = 1; r <= Cfg.SLAYER_MAX_RANK; r++) {
            RankStats s = of(false, Faction.SLAYER, r);
            double dps = (1 + s.attackDamageMult()) * (1 + s.attackSpeedMult());
            System.out.printf("  %2d | %3.0f | %.2f | %.2f | %.2f%n",
                    r, 20.0, 1 + s.attackDamageMult(), 4.0 * (1 + s.attackSpeedMult()), dps);
        }
    }
}
