package com.vampiresyringe;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class SyringeItem extends Item {
    public SyringeItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            // истребитель не может стать демоном: шприц не тратится, шкала крови ему не нужна
            VampireData current = sp.getAttached(VampireMod.DATA);
            if (current != null && current.faction == Faction.SLAYER) {
                sp.displayClientMessage(Component.translatable("vampire.message.slayer_no_syringe"), true);
                return InteractionResultHolder.fail(stack);
            }

            player.getCooldowns().addCooldown(this, 10); // защита от двойного клика

            if (!sp.getAbilities().instabuild) stack.shrink(1);

            boolean first = !sp.getTags().contains(VampireMod.TAG);
            sp.addTag(VampireMod.TAG);

            VampireData d = sp.getAttachedOrCreate(VampireMod.DATA);
            d.boost = Cfg.BOOST_SECONDS;
            // первый укол человеку без фракции делает его демоном БЕЗ ранга (ранг 0): ранг он получит, только поглотив
            // Cfg.DEMON_FIRST_RANK_PROGRESS прогресса (кровь/мобы) — см. RankProgress
            if (Cfg.SYRINGE_MAKES_DEMON && d.faction == Faction.NONE) {
                d.setFaction(Faction.DEMON);
            } else if (Cfg.DEBUG_SYRINGE_RANK_UP && d.faction == Faction.DEMON) {
                d.setRank(d.rank >= d.faction.maxRank ? 1 : d.rank + 1); // только для проверки шкалы крови
            }
            VampireLogic.refreshStats(sp); // Этап 2: новый ранг/фракция -> атрибуты сразу, до полного лечения
            sp.setHealth(sp.getMaxHealth());
            sp.playNotifySound(SoundEvents.GENERIC_DRINK, SoundSource.PLAYERS, 1f, 1f);

            if (first) {
                sp.sendSystemMessage(Component.literal(
                        "§4Яд демона течёт по венам... Ты больше не человек.\n"
                      + "§7Через " + Cfg.BOOST_SECONDS + " сек солнце начнёт тебя жечь — прячься в тени.\n"
                      + "§7Зажми Shift и нажми ПКМ по живому существу — пожрёшь его заживо. Зажми §c[")
                        .append(Component.keybind("key.vampire.regen").withStyle(ChatFormatting.RED))
                        .append(Component.literal("§c]§7 — быстрая регенерация (клавишу можно сменить в настройках управления).\n"
                      + "§7Ранга пока нет: поглоти достаточно крови или мобов (§c" + Cfg.DEMON_FIRST_RANK_PROGRESS + "§7 очков прогресса).")));
            } else {
                sp.sendSystemMessage(Component.literal("§cЕщё одна доза. Кровь кипит!"));
            }

            if (d.faction != Faction.NONE) {
                sp.sendSystemMessage(Component.literal("§7Фракция: §c")
                        .append(Component.translatable(d.faction.langKey()))
                        .append(Component.literal("§7 · ранг: §c"))
                        .append(Component.translatable(d.faction.rankLangKey(d.rank)))
                        .append(Component.literal("§7 · капель крови: §c" + BloodScale.maxDrops(d.faction, d.rank))));
            }
        }

        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
