package com.vampiresyringe;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Сервер -> клиент: состояние игрока для HUD.
 * Тег игрока (/tag ... vampire) живёт только на сервере, поэтому клиенту нужно сообщать об этом отдельно —
 * от этого зависит, показывать ли капли крови вместо обычной полоски голода.
 * Фракция и ранг определяют максимум крови (длину шкалы), поэтому едут в том же пакете.
 * Текущая кровь отдельно не передаётся: она уже лежит в уровне голода, который ваниль синхронизирует сама.
 * Источник истины — сервер; клиент эти значения только читает.
 */
public record VampireStatePayload(boolean vampire, Faction faction, int rank, int rankProgress, int sunBurnTicks)
        implements CustomPacketPayload {

    /** Состояние «не вампир, фракции нет». */
    public static final VampireStatePayload HUMAN = new VampireStatePayload(false, Faction.NONE, 0, 0, 0);

    public static final CustomPacketPayload.Type<VampireStatePayload> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(VampireMod.MOD_ID, "vampire_state"));

    public static final StreamCodec<ByteBuf, VampireStatePayload> CODEC = new StreamCodec<>() {
        @Override
        public VampireStatePayload decode(ByteBuf buf) {
            boolean vampire = buf.readBoolean();
            Faction faction = Faction.byOrdinal(buf.readUnsignedByte());
            int rank = buf.readUnsignedByte();
            int rankProgress = buf.readInt();
            int sunBurnTicks = buf.readInt();
            return new VampireStatePayload(vampire, faction, faction.clampRank(rank), rankProgress, sunBurnTicks);
        }

        @Override
        public void encode(ByteBuf buf, VampireStatePayload p) {
            buf.writeBoolean(p.vampire());
            buf.writeByte(p.faction().ordinal());
            buf.writeByte(p.rank());
            buf.writeInt(p.rankProgress());
            buf.writeInt(p.sunBurnTicks());
        }
    };

    /** Снимок данных игрока для отправки; data == null — данных нет (человек, ни разу не получавший данные). */
    public static VampireStatePayload of(boolean vampire, VampireData data) {
        if (data == null) return vampire ? new VampireStatePayload(true, Faction.NONE, 0, 0, 0) : HUMAN;
        return new VampireStatePayload(vampire, data.faction, data.rank, data.rankProgress, data.sunBurnTicks);
    }

    /** Максимум крови (очков) для этого состояния — тот же расчёт, что и на сервере. */
    public double maxBlood() {
        return BloodScale.maxBlood(faction, rank);
    }

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
