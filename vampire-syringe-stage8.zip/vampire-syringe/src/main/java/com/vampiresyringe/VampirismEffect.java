package com.vampiresyringe;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

/**
 * Единственный видимый эффект демона. Уровень демона = уровень эффекта (Демонизм, II, III, IV, V).
 * Сами баффы (скорость, сила, прыгучесть, ускорение, ночное зрение, слабость на солнце…) выдаёт VampireLogic
 * скрытыми эффектами без иконок, поэтому на экране остаётся только «Демонизм».
 */
public class VampirismEffect extends MobEffect {
    public VampirismEffect() {
        super(MobEffectCategory.NEUTRAL, 0x8B0000);
    }
}
