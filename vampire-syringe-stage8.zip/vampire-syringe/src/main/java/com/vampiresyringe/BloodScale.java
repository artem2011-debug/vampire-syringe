package com.vampiresyringe;

/**
 * Расчёт максимума крови по фракции и рангу. Без зависимостей от Minecraft —
 * сервер использует его для ограничения крови, клиент — для отрисовки шкалы.
 *
 * Максимум = Cfg.MAX_BLOOD * множитель, округлённый до целой капли и ограниченный [MAX_BLOOD .. MAX_BLOOD_CAP].
 * Демон: множитель = 1 + (рангов Низшего выше первого) * LOWER_STEP + (рангов Высшего) * UPPER_STEP.
 */
public final class BloodScale {
    private BloodScale() {}

    public static double multiplier(Faction faction, int rank) {
        if (faction == Faction.DEMON) {
            int r = faction.tableRank(rank); // «без ранга» = как ранг 1
            int lower = Math.min(r, Cfg.DEMON_LOWER_RANKS) - 1;   // 0..5
            int upper = Math.max(0, r - Cfg.DEMON_LOWER_RANKS);   // 0..6
            return 1.0 + lower * Cfg.DEMON_LOWER_BLOOD_MULT_STEP + upper * Cfg.DEMON_UPPER_BLOOD_MULT_STEP;
        }
        if (faction == Faction.SLAYER) return Cfg.SLAYER_BLOOD_MULT;
        return 1.0;
    }

    /** Максимум крови в очках (всегда кратен Cfg.BLOOD_POINTS_PER_DROP). */
    public static double maxBlood(Faction faction, int rank) {
        double step = Cfg.BLOOD_POINTS_PER_DROP;
        double snapped = Math.round(Cfg.MAX_BLOOD * multiplier(faction, rank) / step) * step;
        return Math.max(Cfg.MAX_BLOOD, Math.min(Cfg.MAX_BLOOD_CAP, snapped));
    }

    /** Сколько капель в шкале при данном максимуме. */
    public static int maxDrops(Faction faction, int rank) {
        return (int) Math.round(maxBlood(faction, rank) / Cfg.BLOOD_POINTS_PER_DROP);
    }

    /** Сколько рядов по HUD_DROPS_PER_ROW капель занимает шкала. */
    public static int rows(int drops) {
        return (drops + Cfg.HUD_DROPS_PER_ROW - 1) / Cfg.HUD_DROPS_PER_ROW;
    }
}
