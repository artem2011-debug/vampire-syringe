package com.vampiresyringe;

/**
 * Самочувствие демона: меньшая из двух долей — здоровье и кровь (0 = при смерти или без капли крови, 1 = всё полное).
 * От него зависят затемнение экрана (клиент, VampireClient) и замедление (сервер, VampireLogic) — расчёт один на всех.
 * Без зависимостей от Minecraft; `main` печатает таблицу: java ... com.vampiresyringe.Vitality
 */
public final class Vitality {
    private Vitality() {}

    /** Здоровье, ниже которого игрок этой фракции не опускается: демон — 1.0F, прочие вампиры — последнее сердце. */
    public static float hpFloor(Faction faction) {
        return faction == Faction.DEMON ? Cfg.DEMON_DEATH_FLOOR_HP : Cfg.LAST_STAND_HP;
    }

    /** Самочувствие 0..1. Здоровье считается от «пола» (на нём — 0), чтобы демон на последней половинке сердца был «пустым». */
    public static double of(double hp, double maxHp, double blood, double maxBlood, double hpFloor) {
        double span = maxHp - hpFloor;
        double hpFrac = span <= 0 ? 1.0 : clamp01((hp - hpFloor) / span);
        double bloodFrac = maxBlood <= 0 ? 1.0 : clamp01(blood / maxBlood);
        return Math.min(hpFrac, bloodFrac);
    }

    /**
     * Сила затемнения 0..1 (0 — экран чистый, 1 — самочувствие нулевое). Реальная непрозрачность считается на клиенте:
     * сила * VITALITY_DARKEN_MAX_ALPHA для всего экрана и сила * VITALITY_VIGNETTE_MAX_ALPHA для краёв.
     */
    public static double darkness(double vitality) {
        double comfort = Cfg.VITALITY_DARKEN_COMFORT;
        if (vitality >= comfort) return 0;
        double t = clamp01((comfort - vitality) / comfort);
        return Math.pow(t, Cfg.VITALITY_DARKEN_CURVE);
    }

    /** Уровень «Замедления» (0 = I) или -1, если замедления нет. */
    public static int slowAmplifier(double vitality) {
        int amp = -1;
        for (int i = 0; i < Cfg.EXHAUST_SLOW_BELOW.length; i++) {
            if (vitality <= Cfg.EXHAUST_SLOW_BELOW[i]) amp = Cfg.EXHAUST_SLOW_AMP[i];
        }
        return amp;
    }

    private static double clamp01(double v) {
        return v < 0 ? 0 : Math.min(v, 1);
    }

    public static void main(String[] args) {
        System.out.println("самочувствие | сила | экран целиком | края (доп.) | замедление");
        for (int i = 10; i >= 0; i--) {
            double v = i / 10.0;
            int amp = slowAmplifier(v);
            double d = darkness(v);
            System.out.printf("%12.1f | %4.2f | %13.2f | %11.2f | %s%n", v, d, d * Cfg.VITALITY_DARKEN_MAX_ALPHA,
                    d * Cfg.VITALITY_VIGNETTE_MAX_ALPHA, amp < 0 ? "нет" : "уровень " + (amp + 1));
        }
        System.out.println("демон: здоровье 20/20, кровь 10/20 -> " + of(20, 20, 10, 20, 1));
        System.out.println("демон: здоровье 20/20, кровь 0/20  -> " + of(20, 20, 0, 20, 1));
        System.out.println("демон: здоровье 1/20,  кровь 20/20 -> " + of(1, 20, 20, 20, 1));
    }
}
