package com.vampiresyringe;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

/** Сохраняемые данные вампира (аналог dynamic properties из Bedrock). */
public final class VampireData {
    /** Фракция в NBT — строкой; неизвестное значение читается как NONE, а не ломает загрузку. */
    private static final Codec<Faction> FACTION_CODEC = Codec.STRING.xmap(Faction::byId, f -> f.id);

    public static final Codec<VampireData> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.DOUBLE.optionalFieldOf("blood", Cfg.MAX_BLOOD / 2).forGetter(d -> d.blood),
            Codec.DOUBLE.optionalFieldOf("xp", 0.0).forGetter(d -> d.xp),
            Codec.INT.optionalFieldOf("level", 1).forGetter(d -> d.level),
            Codec.INT.optionalFieldOf("boost", 0).forGetter(d -> d.boost),
            FACTION_CODEC.optionalFieldOf("faction", Faction.NONE).forGetter(d -> d.faction),
            Codec.INT.optionalFieldOf("rank", 0).forGetter(d -> d.rank),
            Codec.INT.optionalFieldOf("rank_progress", 0).forGetter(d -> d.rankProgress),
            Codec.INT.optionalFieldOf("sun_burn_ticks", 0).forGetter(d -> d.sunBurnTicks)
    ).apply(i, VampireData::new));

    public double blood;      // 0..maxBlood()
    public double xp;         // выпитая кровь суммарно
    public int level;         // 1..5
    public int boost;         // секунд «Превращения» осталось
    public Faction faction;   // NONE / DEMON / SLAYER
    public int rank;          // NONE: 0; DEMON: 1..12; SLAYER: 1..6
    public int rankProgress;  // прогресс до следующего ранга (порог — rankUpProgress())
    public int sunBurnTicks;  // таймер горения от солнца, тиков (логика — на этапе «солнце»)

    public VampireData() {
        this(Cfg.MAX_BLOOD / 2, 0, 1, 0, Faction.NONE, 0, 0, 0);
    }

    public VampireData(double blood, double xp, int level, int boost,
                       Faction faction, int rank, int rankProgress, int sunBurnTicks) {
        this.blood = blood;
        this.xp = xp;
        this.level = level;
        this.boost = boost;
        this.faction = faction == null ? Faction.NONE : faction;
        this.rank = rank;
        this.rankProgress = rankProgress;
        this.sunBurnTicks = sunBurnTicks;
        normalize();
    }

    /** Максимум крови при текущих фракции и ранге (очков). */
    public double maxBlood() {
        return BloodScale.maxBlood(faction, rank);
    }

    /** Прогресс, нужный для следующего ранга (0 — ранг максимальный). */
    public int rankUpProgress() {
        return faction.rankUpProgress(rank);
    }

    /** Смена фракции: ранг становится начальным, прогресс обнуляется. */
    public void setFaction(Faction f) {
        this.faction = f == null ? Faction.NONE : f;
        this.rank = this.faction.minRank();
        this.rankProgress = 0;
        normalize();
    }

    /** Смена ранга внутри фракции: прогресс обнуляется. */
    public void setRank(int newRank) {
        this.rank = newRank;
        this.rankProgress = 0;
        normalize();
    }

    /** Приводит поля в допустимые пределы (после загрузки из NBT, смены ранга и т.п.). */
    public void normalize() {
        rank = faction.clampRank(rank);
        rankProgress = rankUpProgress() == 0 ? 0 : Math.max(0, rankProgress);
        sunBurnTicks = Math.max(0, Math.min(Cfg.SUN_BURN_MAX_TICKS, sunBurnTicks));
        blood = Math.max(0, Math.min(maxBlood(), blood));
    }
}
