package com.vampiresyringe;

/**
 * Солнечное горение демона (Этап 3): урон и длительность догорания по рангу. Без зависимостей от Minecraft:
 * цифры читаются из Cfg, применяет их VampireLogic.
 *
 * Проверка баланса без запуска игры: {@code SunBurn.main} печатает таблицу по всем рангам.
 */
public final class SunBurn {
    private SunBurn() {}

    /** Сколько тиков демон догорает после ухода с солнца (и до какого значения обновляется таймер на солнце). */
    public static int burnTicks(int rank) {
        return Cfg.DEMON_SUN_BURN_TICKS[Faction.DEMON.tableRank(rank) - 1];
    }

    /** Урон от солнца, HP в секунду: от MIN на ранге 1 до MAX на ранге 12, линейно. */
    public static double damagePerSecond(int rank) {
        int r = Faction.DEMON.tableRank(rank);
        double t = (r - 1) / (double) (Cfg.DEMON_MAX_RANK - 1);
        return Cfg.DEMON_SUN_DAMAGE_PER_SEC_MIN + (Cfg.DEMON_SUN_DAMAGE_PER_SEC_MAX - Cfg.DEMON_SUN_DAMAGE_PER_SEC_MIN) * t;
    }

    /** Демон-моб: урон от солнца, HP в секунду (Cfg.DEMON_MOB_SUN_DAMAGE_PER_SEC_*), линейно по рангу. */
    public static double mobDamagePerSecond(int rank) {
        int r = Faction.DEMON.tableRank(rank);
        double t = (r - 1) / (double) (Cfg.DEMON_MAX_RANK - 1);
        return Cfg.DEMON_MOB_SUN_DAMAGE_PER_SEC_MIN + (Cfg.DEMON_MOB_SUN_DAMAGE_PER_SEC_MAX - Cfg.DEMON_MOB_SUN_DAMAGE_PER_SEC_MIN) * t;
    }

    /** Демон-моб: урон за один шаг горения. */
    public static float mobDamagePerStep(int rank) {
        return (float) (mobDamagePerSecond(rank) * Cfg.SUN_BURN_STEP_TICKS / 20.0);
    }

    /** Урон за один шаг горения (Cfg.SUN_BURN_STEP_TICKS тиков). */
    public static float damagePerStep(int rank) {
        return (float) (damagePerSecond(rank) * Cfg.SUN_BURN_STEP_TICKS / 20.0);
    }

    /** java -cp <classes> com.vampiresyringe.SunBurn */
    public static void main(String[] args) {
        System.out.println("МОБ-ДЕМОН ранг | HP (20 + бонус) | урон HP/с | смерть на солнце с полным HP (с) | догорание (с)");
        for (int r = 1; r <= Cfg.DEMON_MAX_RANK; r++) {
            double hp = 20 + Cfg.DEMON_MOB_HEALTH_BONUS[r - 1];
            System.out.printf("  %2d | %4.0f | %4.2f | %5.1f | %4.1f%n", r, hp, mobDamagePerSecond(r),
                    hp / mobDamagePerSecond(r), burnTicks(r) / 20.0);
        }
        System.out.println();
        System.out.println("DEMON ранг | HP | урон HP/с | смерть на солнце с полным HP (с) | догорание (с) | урон догорания (HP / % HP) | касание солнца на 1 шаг: урон (HP / % HP)");
        for (int r = 1; r <= Cfg.DEMON_MAX_RANK; r++) {
            double hp = 20 + RankStats.of(true, Faction.DEMON, r).maxHealthBonus();
            double dps = damagePerSecond(r);
            double step = damagePerStep(r);
            int afterSteps = burnTicks(r) / Cfg.SUN_BURN_STEP_TICKS;
            double after = afterSteps * step;
            double touch = step + after; // один шаг на солнце + всё догорание
            System.out.printf("  %2d | %4.0f | %4.2f | %5.1f | %4.1f | %5.1f / %3.0f%% | %5.1f / %3.0f%%%n",
                    r, hp, dps, hp / dps, burnTicks(r) / 20.0, after, 100 * after / hp, touch, 100 * touch / hp);
        }
    }
}
